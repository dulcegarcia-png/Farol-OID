# Histórico de funcionalidades

Versão do pacote: 24/11/2026. As funcionalidades abaixo foram entregues em sequência e estão todas no `farol-oid.html` atual.

1. **Consulta dos casos por time.** Abas OOS, Simba e LW Suits, com link do ticket, resumo do ticket, passo a passo e aba de resposta enviada. Primeiros casos lidos à mão.
2. **Dez casos completos.** Ampliação para JOI-395, 397, 396, 394, 393, 392, 391, 390, 360 e 369.
3. **Paleta do Nubank e tela clara e escura.** Roxo `#820ad1`, com tema que segue o aparelho.
4. **Botão de tema com sol e lua.**
5. **Botão Atualizar.** Lê Slack e Jira pelos conectores de quem clica e resume com o Claude.
6. **Dados compartilhados.** Banco da página: todos veem os mesmos casos, e a atualização de uma pessoa aparece para todas. Trava para duas pessoas não atualizarem ao mesmo tempo. Nome “Farol OID” e desenho do farol.
7. **Assistente no canto inferior direito**, com perguntas sugeridas.
8. **Mascote “Inspetor Roxinho”** no botão, no cabeçalho e nas respostas do assistente.
9. **Sugestões de pergunta em lista vertical**, dentro da conversa, com o link “Ver sugestões de perguntas”.
10. **Leitura do canal inteiro.** Paginação desde a abertura do canal, registro de todos os casos para todos e resumo dos pendentes, com botão Parar. Classificação de pedidos de dossiê e fraude SISBAJUD como LW Suits.
11. **Plano de ação.** Botão e aba “Plano de ação”: plano por caso (causa, ações, prevenção e indicador), geração dos planos pendentes e plano consolidado em temas. Planos iniciais dos 10 casos e consolidado inicial gravados.
12. **Filtro por mês de abertura e busca por datas.** Filtro mensal em todas as abas, data de abertura em cada caso e busca por prazo, abertura e datas dos passos.
13. **Correção de privacidade.** Removido do resumo embutido do JOI-395 o CNPJ de uma pessoa jurídica do caso. Passou a haver uma verificação no teste para impedir CPF e CNPJ nos dados embutidos.
14. **Código separado em `src/`** (HTML, CSS e JavaScript), com `build.js` para montar o arquivo único e `docs/DEPENDENCIAS.md`.

## Limitações conhecidas

- A classificação por time depende do que a thread mostra. Casos ainda não lidos aparecem na aba OOS ou LW Suits de forma provisória.
- Casos criados a partir de uma resposta dentro de uma thread (como o JOI-396) só são encontrados se já estiverem na página.
- Mensagens humanas que citam um JOI sem link (sem `browse/JOI-nnn`) não são detectadas.
- O filtro de período é por mês de abertura. Não há filtro por prazo nem por período livre.
- O plano consolidado não é filtrado por mês.
- Cada leitura de caso leva cerca de um minuto e consome o uso do Claude de quem clica.
