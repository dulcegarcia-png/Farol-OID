// Teste rápido: carrega farol-oid.html num ambiente simulado (sem Slack, Jira, Claude ou navegador)
// e confere as telas principais e as regras de validação. Uso: node tests/smoke-test.js
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const html = fs.readFileSync(path.join(__dirname, "..", "farol-oid.html"), "utf8");
const js = html.split("<script>")[1].split("</script>")[0];

const els = {};
function el(id) {
  return (els[id] = els[id] || {
    id, innerHTML: "", textContent: "", value: "", hidden: false, disabled: false, className: "", style: {},
    setAttribute() {}, getAttribute() { return null; }, addEventListener() {}, insertAdjacentHTML() {},
    appendChild() {}, scrollIntoView() {}, focus() {}, querySelector() { return null; }, closest() { return null; },
    childNodes: [], classList: { add() {}, remove() {} }
  });
}
const ctx = {
  document: {
    getElementById: el, querySelector: () => el("x"), querySelectorAll: () => [],
    createElement: () => el("c" + Math.random()), documentElement: { getAttribute: () => null, setAttribute() {} }
  },
  window: { claude: undefined, matchMedia: () => ({ matches: false }), innerWidth: 1200 },
  localStorage: { getItem: () => null, setItem() {} }, console
};
vm.createContext(ctx);

let falhas = 0;
function confere(nome, ok, detalhe) {
  console.log((ok ? "OK    " : "FALHA ") + nome + (detalhe ? " (" + detalhe + ")" : ""));
  if (!ok) falhas++;
}
const run = (code) => vm.runInContext(code, ctx);

try {
  vm.runInContext(js, ctx);
  confere("o script carrega sem erro", true);
} catch (e) {
  confere("o script carrega sem erro", false, e.message);
  process.exit(1);
}

confere("sem CPF nem CNPJ nos dados embutidos", !/\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/.test(js) && !/\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/.test(js));
{
  const { spawnSync } = require("child_process");
  const r = spawnSync(process.execPath, [path.join(__dirname, "..", "build.js"), "--check"], { encoding: "utf8" });
  confere("farol-oid.html está em dia com src/", r.status === 0, (r.stdout + r.stderr).trim());
}
confere("sem chamadas de rede no código", !/fetch\(|XMLHttpRequest|WebSocket/.test(js));

const nCasos = run("CASES.length");
confere("10 casos embutidos", nCasos === 10, "encontrados: " + nCasos);
confere("todos os casos embutidos têm plano de ação", run("CASES.every(function (c) { return c.plano; })"));
confere("há casos em OOS, Simba e LW Suits", run("['OOS','Simba','LW Suits'].every(function (t) { return CASES.some(function (c) { return c.team === t; }); })"));

for (const aba of ["OOS", "Simba", "LW Suits", "Resposta enviada", "Plano de ação"]) {
  try {
    run("active = " + JSON.stringify(aba) + "; render();");
    confere("renderiza a aba " + aba, els.panel.innerHTML.length > 100);
  } catch (e) {
    confere("renderiza a aba " + aba, false, e.message);
  }
}

run('active = "OOS"; open["JOI-395"] = true; render();');
confere("caso expandido mostra o plano de ação sugerido", /Plano de ação sugerido/.test(els.panel.innerHTML));
confere("caso mostra a data de abertura", /Aberto em 13\/11\/2026/.test(els.panel.innerHTML));

els.month.value = "2026-10";
run('active = "Simba"; render();');
confere("filtro de mês mostra só casos do mês", (els.panel.innerHTML.match(/class="case( open)?"/g) || []).length === 1);
els.month.value = "";

els.q.value = "19/11";
run('active = "OOS"; render();');
confere("busca por data (19/11) encontra casos", (els.panel.innerHTML.match(/class="case( open)?"/g) || []).length >= 1);
els.q.value = "";

const lim = run('cleanCase("JOI-500", { team: "X", state: "hack", slack: "12", steps: [{ when: "1", text: "<b>x</b>" }] })');
confere("limpador troca time e situação inválidos", lim && lim.team === "OOS" && lim.state === "wip");
confere("limpador descarta ID inválido", run('cleanCase("../x", {})') === null);
confere("limpador descarta ID de thread inválido", lim && lim.slack === "");

const lista = run('parseChannel("=== Message from A (U) at x ===\\nMessage TS: 1794950427.203989\\n> :reiteracao-oid: <https://nubank.atlassian.net/browse/JOI-397|JOI-397 - Título>\\n>  :prazo: Prazo: 2026-11-27\\n> Thread: 6 replies (latest: x)")');
confere("lê mensagem do canal (id, título, prazo, respostas)",
  lista.length === 1 && lista[0].id === "JOI-397" && lista[0].title === "Título" && lista[0].prazo === "27/11/2026" && lista[0].replies === 6);
confere("ignora mensagem de alinhamento",
  run('parseChannel("=== Message from A (U) at x ===\\nMessage TS: 1.2\\n> :agora-alinhamentos: <https://nubank.atlassian.net/browse/JOI-375|JOI-375|X>")').length === 0);
confere("classifica pedido de dossiê como LW Suits",
  run('parseChannel("=== Message from A (U) at x ===\\nMessage TS: 1794950427.203989\\n> :important_flag: <!subteam^S0B7QBYKGD8|@lawsuits-oid> <https://nubank.atlassian.net/browse/JOI-284|JOI-284 - Ajuda>")')[0].team === "LW Suits");

confere("montagem do contexto do assistente", run("chatContext().length") > 1000);
confere("prompt de leitura pede o plano de ação", /plano/.test(run('buildPrompt("JOI-1", "01/01/2026", {}, "t")')));

const xss = run('PLAN_DOC = cleanPlanDoc({ at: 1, n: 1, temas: [{ tema: "T <b>x</b>", casos: ["JOI-395", "x"], prioridade: "Alta" }] }); active = "Plano de ação"; render(); 1');
confere("texto do plano consolidado é escapado", !/T <b>x<\/b>/.test(els.panel.innerHTML) && /T &lt;b&gt;/.test(els.panel.innerHTML));

console.log(falhas ? "\n" + falhas + " verificação(ões) falharam." : "\nTodas as verificações passaram.");
process.exit(falhas ? 1 : 0);
