// Monta o arquivo único farol-oid.html a partir de src/index.html + src/styles.css + src/app.js.
// Uso: node build.js           (gera farol-oid.html)
//      node build.js --check   (confere se farol-oid.html está igual ao que o build geraria)
const fs = require("fs");
const path = require("path");

const read = (p) => fs.readFileSync(path.join(__dirname, p), "utf8");
const tpl = read("src/index.html");
const css = read("src/styles.css");
const js = read("src/app.js");

for (const marca of ["/*@@STYLES@@*/", "/*@@SCRIPT@@*/"]) {
  if (tpl.split(marca).length !== 2) {
    console.error("Marcador ausente ou repetido em src/index.html: " + marca);
    process.exit(1);
  }
}
if (js.includes("</script>")) {
  console.error("src/app.js não pode conter a sequência </script>.");
  process.exit(1);
}

// split/join evita que "$" no código seja interpretado como padrão de substituição
const saida = tpl.split("/*@@STYLES@@*/").join(css).split("/*@@SCRIPT@@*/").join(js);
const destino = path.join(__dirname, "farol-oid.html");

if (process.argv.includes("--check")) {
  const atual = fs.existsSync(destino) ? fs.readFileSync(destino, "utf8") : "";
  if (atual === saida) {
    console.log("OK: farol-oid.html está igual ao resultado do build.");
    process.exit(0);
  }
  console.error("DIFERENTE: rode `node build.js` para regenerar farol-oid.html.");
  process.exit(1);
}
fs.writeFileSync(destino, saida);
console.log("Gerado farol-oid.html (" + saida.length + " caracteres).");
