# Farol OID

Ferramenta de consulta dos casos do canal **#operational-intelligence-desk** (Slack). Para cada caso mostra o link do ticket no Jira, um resumo do que o analista registrou, o passo a passo da thread, a resposta enviada e um plano de ação para tratar o caso e evitar que outros iguais aconteçam.

- **Formato:** uma página HTML única (`farol-oid.html`, cerca de 1.900 linhas e 130 KB), sem dependências de código externo. O código-fonte está separado em `src/` e um script (`build.js`) monta o arquivo único.
- **Onde roda hoje:** como *artifact* publicado no claude.ai, em https://claude.ai/artifact/KTNyW3rftFRejgVRhzoHcR
- **Data deste pacote:** 24/11/2026

## O que tem neste pacote

| Arquivo | Para quê |
|---|---|
| `farol-oid.html` | A ferramenta pronta, em um único arquivo (HTML, CSS e JavaScript). É o que se publica ou hospeda. |
| `src/index.html`, `src/styles.css`, `src/app.js` | O código-fonte separado em três arquivos. |
| `build.js` e `package.json` | Montam o arquivo único a partir de `src/` (`node build.js`). Não há pacotes para instalar. |
| `manifest/capabilities.json` | As permissões que a página declara ao claude.ai (banco, conectores, Claude e usuário). |
| `docs/FUNCIONAMENTO.md` | Tudo que a ferramenta faz, tela por tela, e como cada botão se comporta. |
| `docs/ARQUITETURA.md` | Como o código está organizado, o fluxo de dados e as chamadas a Slack, Jira e Claude. |
| `docs/DEPENDENCIAS.md` | Todas as dependências (código, navegador, claude.ai, conectores, ferramentas) e os valores fixos do código. |
| `docs/MODELO-DE-DADOS.md` | Os documentos gravados no banco compartilhado, com exemplos. |
| `docs/PROMPTS.md` | Os textos exatos enviados ao Claude (extraídos do código). |
| `docs/INTEGRACAO-HUB.md` | Como colocar no HUB do time, o que funciona em cada opção e o que trocar para rodar fora do claude.ai. |
| `docs/PEDIR-AJUSTES.md` | Texto pronto para pedir ajustes no futuro. |
| `CHANGELOG.md` | Histórico das funcionalidades. |
| `tests/smoke-test.js` | Teste rápido que carrega a página e confere as telas principais. |

## Caminho mais curto para o HUB

1. **Recomendado:** colocar no HUB o **link do artifact** (ou embuti-lo, se o HUB aceitar iframe). Assim o banco compartilhado e o botão Atualizar continuam funcionando. Veja `docs/INTEGRACAO-HUB.md`, opção A.
2. Se o HUB precisa hospedar o arquivo, ele abre fora do claude.ai em **modo leitura**, com os 10 casos que vêm embutidos no código. Atualizar, assistente e dados compartilhados exigem o claude.ai (opção B) ou um backend próprio (opção C).

## Requisitos para tudo funcionar (opção A)

- Quem usa precisa estar na organização, com a conta logada no claude.ai.
- Para **ver** os casos: acesso ao artifact (qualquer nível de compartilhamento).
- Para **atualizar** e gerar planos: nível **Colaborador (Contributor)** ou superior no compartilhamento.
- Para o botão Atualizar: ser membro do canal privado #operational-intelligence-desk e ter os conectores **Slack** e **Atlassian** (Jira) conectados na própria conta.
- O resumo, o plano e o assistente usam o Claude da conta de quem clica, então consomem o uso dessa pessoa.

## Atenção: dados sensíveis

Os casos tratam de ofícios judiciais, quebra de sigilo bancário e dados de clientes. Antes de ampliar o público do HUB:

- o arquivo `farol-oid.html` carrega **10 casos embutidos** (resumos de tickets, passo a passo e respostas). Quem tiver o arquivo lê esse conteúdo;
- o banco compartilhado fica no artifact e só é lido por quem tem acesso a ele;
- os resumos gerados pelo Claude passam por regras para não incluir CPF, CNPJ de pessoa física nem número de conta, mas isso não substitui a revisão humana.

Este pacote **não inclui** o conteúdo do banco compartilhado (os casos já lidos pela atualização). Se o HUB precisar migrar esses dados, peça uma exportação separada (veja `docs/INTEGRACAO-HUB.md`).

## Como montar e testar

```bash
node build.js            # gera farol-oid.html a partir de src/
node build.js --check    # confere se o arquivo único está em dia com src/
node tests/smoke-test.js # teste rápido
```

Precisa só do Node.js 18 ou mais novo. O teste não acessa Slack, Jira nem Claude.
