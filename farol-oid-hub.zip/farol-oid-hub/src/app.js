
var SLACK = "https://nubank.slack.com/archives/C0A0EC24DJ6/p";
var JIRA = "https://nubank.atlassian.net/browse/";

var CASES = [
  {
    id: "JOI-395", replies: 6, team: "OOS", title: "Crime de desobediência",
    prazo: "18/11/2026", jiraStatus: "Em análise", state: "ok", stateLabel: "Finalizado em 19/11",
    owner: "Aberto por Sidiney Nascimento", slack: "1794602433923569", full: true,
    ticket: [
      "Recebido o documento “Referências – TC 851/2026”, com natureza de desobediência de ordem judicial. O ofício pede apenas dados cadastrais do responsável legal da Nu Pagamentos para oitiva em procedimento policial.",
      "A alegação é que o Nubank teria descumprido ordem de fornecer informações bancárias da pessoa jurídica citada no ofício.",
      "O analista localizou o cadastro na cabine em 16/07 (ID 323126), com resposta em 24/07, mas citando a pessoa física, dados que não condizem com o pedido. Depois de 4 recusas via Athena, o recebimento foi acusado em 15/10 e a execução do mesmo dia também enviou dados da pessoa física. Em 21/08 já havia sido expedida resposta correta, no processo 1510217-72.2024.8.26.0071.",
      "Pede que o OID prossiga com a tratativa. Comentário no ticket registra também o ticket #126726038 do Zendesk."
    ],
    steps: [
      { when: "13/11 · 17:40", text: "O caso entra no canal como sanção aplicada, com prazo de 5 dias." },
      { when: "13/11 · 17:49", text: "Mariana Guareschi adianta que será preciso apoio de Legal e um dossiê explicando o comportamento da Athena. O ofício é enviado a Legal para ciência." },
      { when: "13/11 · 18:06", text: "Tamily Mascarenhas (QA) sinaliza que o caso está no radar e aguarda o parecer de OOS para a análise de QA." },
      { when: "17/11 · 12:13", text: "Vitor Cassara compartilha o dossiê no Google Docs." },
      { when: "17/11 · 12:14", text: "Pela urgência, Mariana compartilha com Legal e pede que o dossiê seja aberto também para João Terra." },
      { when: "19/11 · 10:27", text: "Mariana posta o “OID Finalizado”. O dossiê segue para o escritório criminal parceiro, que conduz a defesa." }
    ],
    response: {
      title: "Reincidência no envio de dados da pessoa física em vez da PJ e instauração de TC por desobediência de ordem judicial – Processos 1506374-31.2026.8.26.0071 / 1510217-72.2024.8.26.0071.",
      resumo: "Desde 24/02/2026 há ordem de quebra de sigilo da PJ. Ao longo do ano, quatro solicitações foram recusadas por CNPJ inválido, sem uso do CPF da representante para localizar a empresa. Duas respostas (24/07 e 15/10) enviaram dados da pessoa física, e os dados corretos da PJ só foram entregues em 21/08, no processo 1510217-72. Em 11/11 chegou o TC 851/2026, que originou este OID.",
      gaps: [
        "Recusas por CNPJ inválido sem busca por identificador alternativo (CPF da representante)",
        "Ausência de conferência do titular (PF x PJ) antes do envio, com erro repetido em 24/07 e 15/10",
        "Nenhum mecanismo de alerta para reiteração ou ofício repetido sobre o mesmo alvo"
      ],
      riscos: [
        "Alto: responsabilização criminal/pessoal do responsável legal por desobediência, com oitiva em procedimento policial",
        "Alto: exposição indevida de dados da pessoa física (sigilo bancário/LGPD), em duas ocasiões",
        "Alto: reincidência do erro em 15/10, mesmo após a resposta correta de 21/08",
        "Médio: dano reputacional e de relacionamento com o Judiciário e a Polícia Civil"
      ],
      desfecho: "O escritório criminal parceiro vai (i) procurar a escrivã para propor petição de esclarecimentos por escrito no lugar da oitiva do representante e (ii) se aceito, apresentar a petição mostrando que não houve desobediência e pedindo a remessa dos autos ao Ministério Público para arquivar o termo circunstanciado.",
      by: "Mariana Guareschi, 19/11/2026"
    }
  },
  {
    id: "JOI-397", replies: 6, team: "Simba", title: "Intimação de descumprimento – quebra de sigilo bancário",
    prazo: "27/11/2026", jiraStatus: "Em análise", state: "ok", stateLabel: "Finalizado em 19/11",
    owner: "Felipe Rocha (Simba) · responsável no Jira: Dulce Cosmo", slack: "1794950427203989", full: true,
    ticket: [
      "O caso foi registrado em OID pelo tom ameaçador da autoridade, diante de divergência no cumprimento nas últimas tratativas.",
      "Linha do tempo: (1) o 1º ofício tratava de movimentações fraudulentas em compras no débito, e o juiz restringiu a quebra de sigilo ao estabelecimento, não à cliente; (2) no atendimento inicial (ID 330369, 15/09/2026) a quebra foi feita contra a cliente, com dados cadastrais, dados 3.454 e carta resposta, sem esclarecer as compras no débito; (3) a reiteração (recebida em 13/11 via Triagem OOS, ID 339500) retificou o pedido e intimou de forma incisiva a atender a quebra do estabelecimento.",
      "Operacionalização: o ofício foi cadastrado no ID 339500, com prazo de 10 dias úteis pela matriz de prazos Simba, e a carta resposta foi refeita com as compras no débito em planilha, direcionando o pedido à adquirente responsável.",
      "Pede apoio dos times envolvidos para revisar a tratativa e a carta resposta antes de nova expedição ao juízo."
    ],
    steps: [
      { when: "17/11 · 18:20", text: "O caso entra como reiteração, com prazo de 27/11." },
      { when: "17/11 · 18:23", text: "Felipe Rocha detalha a linha do tempo e a operacionalização, e pede revisão da tratativa e da carta resposta. SLA de 27/11." },
      { when: "18/11 · 10:06", text: "Mariana Guareschi pede acesso aos links e ao drive de Simba. Felipe libera às 10:21." },
      { when: "18/11 · 11:20", text: "Mariana revisa a carta: ajusta o layout ao novo padrão de respostas, deixa claro que o retorno anterior está sendo retificado e cita a PagSeguro como adquirente. Sugere enviar também aos e-mails do TJSP e da Polícia Civil e pedir ao escritório parceiro o protocolo direto nos autos. Questiona se um ofício de 2025 sobre o processo foi respondido." },
      { when: "18/11 · 13:54", text: "Felipe informa que não há outros IDs na cabine além dos dois citados (330369 e 339500) e que o ofício de 2025 não traz o CPF da cliente." },
      { when: "19/11 · 10:23", text: "Mariana posta o “OID Finalizado” com gaps e riscos." }
    ],
    response: {
      title: "Quebra de sigilo atendida contra a cliente (e não o estabelecimento) e reiteração incisiva do juízo.",
      resumo: "O ofício restringia a quebra ao estabelecimento, buscando informações do beneficiário de uma compra no cartão de débito, mas o atendimento inicial foi direcionado à cliente, sem esclarecer as compras no débito. Sobreveio reiteração com tom ameaçador, que originou este OID.",
      gaps: [
        "Leitura/triagem inicial equivocada do escopo da ordem judicial",
        "Resposta inicial incompleta, sem esclarecimento das compras no débito e sem direcionamento à adquirente",
        "Ofício de 2025 sem rastreabilidade (sem ID na cabine): não se sabe se foi respondido"
      ],
      riscos: [
        "Exposição indevida de dados da cliente (sigilo bancário/LGPD)",
        "Risco de sanções por descumprimento de ordem judicial (multa, astreintes, desobediência), dado o tom ameaçador do juízo",
        "Ofício de 2025 possivelmente sem resposta, agravando o histórico de descumprimento"
      ],
      desfecho: "Deixado para verificação da necessidade de realinhamento interno.",
      extra: { label: "Carta resposta revisada para o juízo", url: "https://docs.google.com/document/d/1tuba68uezAQGF-uZZ2mEt3pSaHOp1vSB7WQNu_c9mTQ/edit?usp=sharing" },
      by: "Mariana Guareschi, 19/11/2026"
    }
  },
  {
    id: "JOI-396", team: "LW Suits", title: "Dossiê – fraude SISBAJUD – Processo 4220144-26.2026.8.26.0100",
    prazo: "02/12/2026", jiraStatus: "Em análise", state: "wip", stateLabel: "Em andamento",
    owner: "Íris Almeida (responsável) · aberto por Mariana Guareschi", slack: "1794856160520799", full: true,
    ticket: [
      "Solicitação de informações, aberta via Lions, para elaborar o dossiê do processo 4220144-26.2026.8.26.0100. É um caso de fraude SISBAJUD, já checado por Adriana Azevedo.",
      "Definido na thread que o dossiê segue via OID, com condução concentrada no canal. Legal foi acionado e há direcionamento direto com o escritório para a defesa, em fluxo especial e de exceção, a confirmar com Legal.",
      "Critérios: elaborar o dossiê a partir dos exemplos anteriores compartilhados; confirmar com Legal se o caso segue o fluxo especial; sinalizar Larissa Araujo depois de confirmado que será via OID."
    ],
    steps: [
      { when: "16/11 · 16:09", text: "Lívia Zaroni abre o caso no canal com o número do processo." },
      { when: "16/11 · 16:14", text: "Lívia explica que a solicitação veio via Lions, é fraude SISBAJUD e deve seguir via OID. Sugere levar o caso a Legal para decidir se segue o fluxo especial. Compartilha 4 exemplos de dossiê e uma contestação." },
      { when: "16/11 · 16:16", text: "Fica combinado sinalizar Larissa Araujo depois da confirmação, para concentrar a condução no canal." },
      { when: "16/11 · 17:02", text: "Mariana Guareschi cria o ticket JOI-396 a partir da mensagem, com Íris Almeida como responsável." },
      { when: "17/11", text: "Íris pede a Adriana Azevedo o ticket de origem e registra o prazo de 02/12." },
      { when: "18/11 · 09:49", text: "Adriana compartilha o doc com as informações das ordens recebidas via SISBAJUD." },
      { when: "19/11 · 10:23", text: "Mariana pede o esboço do dossiê." },
      { when: "19/11 · 17:27", text: "Íris diz que está elaborando o dossiê e entrega até segunda (23/11)." }
    ],
    response: null
  },
  {
    id: "JOI-394", replies: 12, team: "OOS", title: "5005611-51.2026.8.13.0145_10dias_Athena",
    prazo: "20/11/2026 (interno: 18/11)", jiraStatus: "Em análise", state: "ok", stateLabel: "Finalizado em 19/11",
    owner: "Aberto por Giovanna Melo · responsável: Dulce Cosmo", slack: "1794592071531249", full: true,
    ticket: [
      "A autoridade pede os dados de um número de conta, mas o Nubank consta no polo passivo da ação.",
      "O ticket aponta a thread reportada ao time de Legal e informa que o caso foi cadastrado na cabine com o ID 339259."
    ],
    steps: [
      { when: "13/11 · 14:47", text: "O caso entra como ofício fora do padrão, com prazo de 20/11." },
      { when: "13/11 · 15:51", text: "Roberto Serafim (QA) justifica o OID: a vítima é membro do Ministério Público e o Nu foi incluído indevidamente no polo passivo; a conta citada não foi localizada; há ofício anterior respondido (665/2025-GAECIBER) e outro de 15/09 sem confirmação de resposta; é preciso um dossiê com o histórico da conta e o esclarecimento da transferência de 12/12/25 e da recuperação de valores do Limbo." },
      { when: "13/11 · 16:01", text: "Mariana Guareschi lembra que Legal pediu máxima atenção e validação antes do protocolo. Sugere antecipar o prazo para 18/11, já que 20/11 é feriado, e começar pelos dados mais críticos: locais de abertura e movimentação, logs de acesso e geolocalização." },
      { when: "16/11 · 18:17", text: "Vitor Cassara diz que o caso está encaminhado e que faltam informações já pedidas a outros times, por dois tickets: um para localizar uma das contas e outro para as transações com cartão." },
      { when: "16/11 · 19:05", text: "Vitor compartilha a proposta de resposta para análise inicial." },
      { when: "17/11 · 10:04", text: "Mariana ajusta a carta-resposta e pergunta se o ofício de setembro foi respondido. Vitor confirma que não e vai conferir de novo. Mariana compartilha a minuta com Legal." },
      { when: "19/11 · 11:09", text: "Vitor pede que os times analisem os documentos do caso." },
      { when: "19/11 · 12:32", text: "Mariana posta o “OID Finalizado”." },
      { when: "19/11 · 13:30", text: "Vitor confirma que a resposta foi enviada e protocolada." }
    ],
    response: {
      title: "Ofício do MPMG com quebra de sigilo (vítima membro do MP, Nu incluído indevidamente no polo passivo, conta não localizada) – acompanhado pelo escritório criminal parceiro",
      resumo: "Ofício recebido em 10/11/2026 via Athena pede dados bancários por decisão de quebra de sigilo, em caso de possível abertura fraudulenta de conta. O Nu consta por engano como réu e Legal já atua para removê-lo. A conta não foi localizada, há ofício anterior respondido e outro de 15/09 sem confirmação de resposta. O caso veio ao OID pela sensibilidade, com dossiê do histórico da conta e esclarecimento da transferência de 12/12/25 e da recuperação de valores do Limbo.",
      gaps: ["Nenhum gap de execução mapeado"],
      riscos: ["Nenhum risco efetivado neste primeiro momento"],
      boas: ["Antecipar o prazo interno (18/11) por causa do feriado de 20/11 e da validação de Legal"],
      desfecho: "A resposta foi elaborada, revisada pelo fluxo de OID e validada por Legal, dentro do prazo.",
      envio: "Resposta enviada e protocolada em 19/11, às 13:30 (Vitor Cassara).",
      by: "Mariana Guareschi, 19/11/2026"
    }
  },
  {
    id: "JOI-393", replies: 7, team: "OOS", title: "Bloqueio de valores Nu Invest – liquidação de ativos do Banco Master – Processo 1003038-04.2023.8.26.0323",
    prazo: "16/11/2026", jiraStatus: "Cancelado", state: "ok", stateLabel: "Devolvido ao analista",
    owner: "Aberto por Yago Silva · responsável: Dulce Cosmo", slack: "1794591667794159", full: true,
    ticket: [
      "Em 17/03/2026 foi respondido um ofício sobre a transferência de R$ 46.970,49 do bloqueio ligado ao protocolo 20250026715284. Em 26/10 chegou novo ofício pedindo detalhes do bloqueio de R$ 124.138,11 feito via Sisbajud no mesmo protocolo.",
      "O cliente está sem saldo na Nu Invest e os ativos liquidados e transferidos eram CDBs do Banco Master. Resta uma diferença de cerca de R$ 77.167,62 entre o valor bloqueado e o transferido.",
      "A decisão do juiz manda informar em quais ativos estava aplicado o valor, detalhando número de cotas, prazo de liquidação (D+), valor da cota na data do bloqueio (12/02/2025) e na liquidação, valor bruto, valor líquido e a diferença discriminada (tributos, taxas)."
    ],
    steps: [
      { when: "13/11 · 14:41", text: "O caso entra como ofício fora do padrão, com prazo de 16/11." },
      { when: "13/11 · 14:51", text: "Tamily Mascarenhas (QA) pergunta se a Operação teve acesso ou treinamento sobre os CDBs do Banco Master, tema sensível e com visibilidade na mídia, para decidir se o retorno segue pelo analista ou via OID." },
      { when: "13/11 · 15:00", text: "Vitor Cassara aponta que já existe um alinhamento sobre esse tipo de ofício no Confluence, vindo do JOI-280, e pergunta se o caso deve voltar ao analista." },
      { when: "13/11 · 15:09", text: "Mariana Guareschi entende que o caso deixou de ser OID por já haver alinhamento prévio, com três cenários previstos. Sugere que um IC4 valide a resposta ao final." },
      { when: "13/11 · 15:46", text: "Vitor propõe devolver ao analista e a proposta recebe aprovação." },
      { when: "16/11 · 10:37", text: "Mariana posta o “OID Finalizado”: ofício retornado ao analista." }
    ],
    response: {
      title: "Ofício sobre CDB do Banco Master retornado ao analista",
      resumo: "O caso saiu do OID porque já existia orientação enviada à operação para ofícios sobre CDBs do Banco Master. O ofício voltou ao analista, com validação final sugerida por um IC4.",
      gaps: ["Sem gaps mapeados"],
      riscos: ["Sem riscos mapeados"],
      desfecho: "Ofício retornado ao analista.",
      by: "Mariana Guareschi, 16/11/2026"
    }
  },
  {
    id: "JOI-392", replies: 29, team: "OOS", title: "338516 – debêntures em recuperação judicial",
    prazo: "16/11/2026", jiraStatus: "Em análise", state: "ok", stateLabel: "Finalizado em 16/11",
    owner: "Aberto por Aline Laino · responsável: Dulce Cosmo", slack: "1794585293986239", full: true,
    ticket: [
      "Chegou um ofício que reitera um caso já tratado em OID antes, com pasta de histórico.",
      "Pedido principal: esclarecimentos complementares sobre o ativo alcançado por ordem SISBAJUD, explicando por que o valor bloqueado de R$ 2.796,75 não foi depositado e as divergências sobre a natureza do ativo.",
      "Pedidos específicos: histórico completo do investimento (valor na data do bloqueio, natureza, eventual desvalorização e causa), método de apuração do saldo atual, data de recebimento da ordem, providências de conversão, liquidação ou transferência e comprovação ou impedimento."
    ],
    steps: [
      { when: "13/11 · 14:33", text: "Vitor Cassara conta que a analista informou que o assunto já passou pelo OID, mas entende que o pedido atual, só de esclarecimentos, pode ser respondido por ela." },
      { when: "13/11 · 15:14", text: "Roberto Serafim discorda: é um caso singular, com inviabilidade técnica de transferir os valores porque são debêntures de empresa em recuperação judicial. Manter no OID evita desalinhar da resposta anterior." },
      { when: "13/11 · 15:57", text: "Mariana Guareschi concorda em seguir no OID e pede que a resposta explique melhor por que o valor não foi transferido." },
      { when: "16/11 · 11:26", text: "Vitor compartilha a carta-resposta para validação." },
      { when: "16/11 · 11:33", text: "Mariana aponta que o juiz pede o extrato das debêntures e que a resposta precisa explicar a divergência com a anterior, que falava em fundos de investimento. Sugere atribuir à padronização de macros e ao trabalho manual repetitivo." },
      { when: "16/11 · 12:51", text: "O extrato depende de um RPA, com prazo padrão de D+1. Vitor aciona um contato para sair no mesmo dia." },
      { when: "16/11 · 14:39", text: "Sai um extrato, mas outro depende do sistema Sinacor, que estava com problemas." },
      { when: "16/11 · 15:48", text: "Roberto lembra que o juiz quer ver a oscilação do ativo desde o bloqueio. Um extrato com saldo zerado contradiria a resposta e traria risco de terceiro ofício e de penalização." },
      { when: "16/11 · 16:24", text: "Vitor informa que não é possível gerar extratos do período do bloqueio e propõe informar o valor avaliado atual." },
      { when: "16/11 · 16:41", text: "Mariana aciona o PM da área. O extrato enviado por Heitor Cauchioli atende, e Roberto aprova seguir com ele." },
      { when: "16/11 · 16:57", text: "Vitor informa que a resposta foi enviada." },
      { when: "16/11 · 16:58", text: "Mariana posta o “OID Finalizado”." }
    ],
    response: {
      title: "Pedido de transferência de debêntures em recuperação judicial",
      resumo: "Ofício reitera o pedido de esclarecimento sobre a não transferência de valores bloqueados. O ativo são debêntures de empresa em recuperação judicial, com inviabilidade técnica de transferência. Durante o atendimento foi preciso corrigir uma informação equivocada do ofício anterior (que citava fundos de investimento) e superar dificuldades de sistema para gerar o extrato histórico desde o bloqueio, em junho/2025.",
      gaps: [
        "Inconsistência no atendimento anterior: informou bloqueio em fundos de investimento, possivelmente por uso inadequado de macros e trabalho manual, o que exigiu retratação ao juízo",
        "Limitações de sistema: a ferramenta padrão (JudFiles) não atendeu, o processo dependeu de RPA com SLA de D+1 e esbarrou na indisponibilidade do Sinacor",
        "Dado pouco confiável: o primeiro extrato gerado mostrava saldo zerado, o que contradiria a resposta se não houvesse conferência",
        "Dependência de escalonamento: a solução exigiu acionar o PM da área, o que não é escalável"
      ],
      riscos: ["Reputacional: justificar divergências entre a resposta atual e a anterior por erro humano ou macros arranha a credibilidade perante o juízo"],
      envio: "Resposta e extrato enviados em 16/11, às 16:57 (Vitor Cassara).",
      by: "Mariana Guareschi, 16/11/2026"
    }
  },
  {
    id: "JOI-391", replies: 37, team: "OOS", title: "338254 – transferência estornada e valores consumidos",
    prazo: "11/11/2026 (ajustado para 14/11)", jiraStatus: "Done", state: "ok", stateLabel: "Finalizado em 16/11",
    owner: "Aberto por Aline Laino · responsável: Dulce Cosmo", slack: "1794412918774469", full: true,
    ticket: [
      "O ofício manda, “pela derradeira vez”, comprovar a transferência de R$ 1.605,00 para a conta do autor ou, se for inviável, depositar o valor em conta judicial em 10 dias, sob pena de penhora online.",
      "Histórico das respostas: a primeira informou que a transferência não foi possível por inconsistência nos dados bancários e pediu o reenvio; a segunda pediu dilação por nova tentativa, que foi estornada, e o bloqueio foi refeito; em 10/07 nova tentativa foi respondida como efetivada, mas foi revertida e não houve novo bloqueio; duas respostas posteriores repetiram, por engano, que a transferência havia ocorrido.",
      "Como o valor foi externalizado, não foi possível cumprir a transferência judicial. O ticket pergunta se o caso deve seguir via OID."
    ],
    steps: [
      { when: "11/11 · 13:12", text: "Tamily Mascarenhas (QA) observa que não há multa, mas o tom do juiz, o número de reiterações e a evasão dos valores tornam o caso sensível. Propõe tratar em OID ou em OOS com validação do IC4." },
      { when: "11/11 · 13:51", text: "Mariana Guareschi sugere OID com resposta elaborada pelo IC4: é a terceira reiteração, o valor pode ter sido movimentado e a ordem de transferência anterior não foi cumprida." },
      { when: "11/11 · 15:11", text: "Mariana nota que o ofício foi recebido em 04/11 e o prazo é de 10 dias. Vitor Cassara corrige o prazo para 14/11 e dispensa a dilação. O caso segue em OID." },
      { when: "11/11 · 15:19", text: "QA pede para entender o motivo do desbloqueio: falha humana, bug ou ordem do juiz." },
      { when: "12/11 · 15:04", text: "Vitor traz a linha do tempo e conclui que houve falha operacional: o bloqueio não foi mantido depois do estorno, e a informação foi reiterada sem nova checagem. Propõe ajuste a crédito, novo bloqueio e transferência." },
      { when: "12/11 · 16:47", text: "Tamily aponta como gap que o valor estornado deveria voltar bloqueado, como nas transferências via Sisbajud." },
      { when: "12/11 · 18:27", text: "Vitor esclarece: no pagamento de guia, o estorno restabelece o bloqueio; na transferência entre contas feita por outro time, o bloqueio é removido à mão e não volta sozinho. Não houve ordem de desbloqueio. O ponto de falha foi reiterar a informação ao juiz sem revalidar." },
      { when: "13/11 · 09:10", text: "Vitor compartilha a carta-resposta. Mariana revisa e sugere anexar o comprovante da transferência." },
      { when: "13/11 · 17:13", text: "O ajuste é feito e o bloqueio inserido primeiro não surtiu efeito, mas Vitor lançou novo bloqueio a tempo e capturou os valores. A transferência fica para segunda." },
      { when: "16/11 · 10:02", text: "O pagamento judicial é realizado e o valor consta na conta judicial. Strategic Defense aprova a resposta às 10:26." },
      { when: "16/11 · 10:36", text: "Mariana posta o “OID Finalizado”." },
      { when: "16/11 · 11:07", text: "Vitor informa que a resposta foi enviada por e-mail e que o protocolo nos autos foi solicitado." }
    ],
    response: {
      title: "Descumprimento reiterado de ordem judicial (3ª reiteração, “derradeira vez”): valores transferidos e retornados, não bloqueados novamente e consumidos pelo cliente",
      resumo: "O juízo determinou a transferência de valores bloqueados para conta judicial. Em 10/07 a transferência entre contas foi estornada e os valores voltaram à conta do cliente sem novo bloqueio. Em 24/07 reiteramos ao juízo que a transferência estava efetivada, sem revalidar. O cliente movimentou o saldo e ainda recebeu novos créditos acima do valor da ordem. Foram feitos o ajuste a crédito, novo bloqueio (capturado a tempo) e o pagamento da guia, e os valores foram transferidos para a conta judicial nesta resposta.",
      gaps: [
        "Sem novo bloqueio automático quando a transferência entre contas, feita por outro time, é estornada. No pagamento de guia o bloqueio volta automaticamente",
        "Sem monitoramento depois da transferência",
        "Informação reiterada ao juízo sem nova validação no Tristam, o principal ponto de falha",
        "Estorno de 10/07 não identificado pela analista"
      ],
      riscos: [
        "Alto: sanção judicial ou multa, pela 3ª reiteração e pelo tom do magistrado",
        "Alto: credibilidade perante o juízo, por informar transferência efetivada quando não estava",
        "Alto: perda financeira, com valores usados pelo cliente e ajuste a crédito",
        "Alto: recorrência do erro em outras ordens com transferência entre contas",
        "Médio: exposição reputacional e regulatória"
      ],
      desfecho: "Registrado para ciência de Strategic Defense e OOS, para as decisões cabíveis perante o time.",
      envio: "Resposta enviada por e-mail e protocolo nos autos solicitado em 16/11, às 11:07 (Vitor Cassara).",
      by: "Mariana Guareschi, 16/11/2026"
    }
  },
  {
    id: "JOI-390", replies: 46, team: "OOS", title: "Multa aplicada de 5% + 20% em caso de recusa",
    prazo: "10/11/2026 (dilação até 20/11)", jiraStatus: "Done", state: "ok", stateLabel: "Finalizado em 13/11",
    owner: "Aberto por Milene Santos", slack: "1794325671269979", full: true,
    ticket: [
      "Caso crítico que pede análise urgente: o juiz aplicou multa de 5% sobre o valor da causa por ato atentatório à dignidade da justiça e avisou que pode subir para até 20% em caso de descumprimento ou recusa.",
      "É preciso verificar os dados de compensação de 6 boletos, para identificar os bancos arrecadadores, e preparar a defesa para afastar a multa.",
      "Cronologia: em 08/05/2026 o Nubank apresentou extrato e cópias dos boletos emitidos, ressaltando que, como emissor, só tinha acesso aos boletos da própria plataforma; as compensações ocorreram entre 07/03/2025 e 05/12/2025; entre 11 e 14/09/2026 novo ofício reiterou o pedido dos dados de origem e aplicou a multa, com 5 dias para comprovar o pagamento e 10 para enviar as informações faltantes."
    ],
    steps: [
      { when: "10/11 · 13:40", text: "Mariana Guareschi pede dossiê urgente para enviar a Legal e, em paralelo, a resposta ao último ofício." },
      { when: "10/11 · 14:28", text: "Vitor Cassara compartilha o dossiê. Como será preciso acionar outras áreas, propõe pedir dilação de prazo." },
      { when: "10/11 · 14:51", text: "Outro time é acionado por ticket. Às 18:17 a engenharia também é acionada." },
      { when: "10/11 · 16:01", text: "Roberto Serafim confere o Zendesk e confirma a cronologia: ofício de 29/04 respondido em 08/05, novo ofício de 08/06, reiterações em 01/07 e 23/07 sem retorno e decisão da multa em 10/09." },
      { when: "10/11 · 17:15", text: "Ofício foi recebido em 05/11, com 10 dias de prazo. A analista vai pedir dilação de 15 dias." },
      { when: "11/11 · 13:14", text: "Dossiê ajustado e engenharia devolve os dados. Às 15:23 Vitor envia a resposta para validação." },
      { when: "11/11 · 16:13", text: "Mariana questiona por que o Nu não teria os dados da conta de origem e pede que a resposta evite termos técnicos. Às 17:37 aponta que a resposta ficou contraditória, ao tratar o emissor como pagador." },
      { when: "12/11 · 16:10", text: "Informações do time de produto: os boletos foram emitidos no Nu mas pagos na Caixa ou em lotéricas. O arquivo ADDA108 confirma o pagamento, mas não traz os dados de quem pagou. Prazo pós-dilação: 20/11. Resposta e dossiê são validados." },
      { when: "12/11 · 17:09", text: "Dúvida sobre o emissor também ser o pagador. Roberto levanta que o Nu não tem convênio para depósito em espécie e que o boleto em lotérica é um caminho comum. Lívia Zaroni baixa a íntegra do processo para conferir." },
      { when: "13/11 · 10:47", text: "O PM confirma que o dado de pagador vem da Caixa no ADDA108. A resposta deve deixar claro que o preenchimento é responsabilidade da instituição onde ocorreu o pagamento." },
      { when: "13/11 · 12:54", text: "Mariana libera o envio por e-mail e pelo protocolo do escritório parceiro, para garantir a entrega." },
      { when: "13/11 · 14:43", text: "Vitor informa que o protocolo foi feito e a resposta enviada por e-mail, com os comprovantes anexados." },
      { when: "13/11 · 14:57", text: "Mariana posta o “OID Finalizado”." }
    ],
    response: {
      title: "Resposta a ofício judicial sobre a identificação do pagador de seis boletos, com multa aplicada e ameaça de aumento da penalidade",
      resumo: "A Justiça do Trabalho pediu informações sobre os pagadores dos seis boletos e reiterou o ofício mais de seis vezes. Na primeira resposta foram enviados extrato, cópias dos boletos e ficha cadastral; nas seguintes, o pedido foi negado. Depois do contato com o PM, foi confirmado que o arquivo ADDA108, informado pela Caixa, identifica o autor como pagador. Com isso foi preparada e enviada a resposta explicando que o preenchimento do pagador é de responsabilidade da instituição onde ocorreu o pagamento.",
      gaps: [
        "Quebra indevida de sigilo e falta de minimização: a primeira resposta enviou extrato e ficha cadastral que o juízo não pediu",
        "Demora na apuração: já no primeiro ofício a busca e o contato com o PM poderiam ter começado",
        "Busca insuficiente nas reiterações: o número do processo poderia ter localizado os dados dos boletos, em vez de repetir a negativa",
        "Ausência de fluxo de escalonamento e validação para dúvidas ao PM e revisão do escopo antes do envio"
      ],
      riscos: [
        "Impacto financeiro da multa e custo adicional de tratamento do caso",
        "Risco de imagem e desgaste com a autoridade judicial pela demora em fornecer as informações",
        "Exposição de dados protegidos além do necessário, com risco jurídico e regulatório"
      ],
      desfecho: "Sugerida análise de alinhamentos posteriores por Strategic Defense e OOS.",
      envio: "Resposta enviada por e-mail e protocolada pelo escritório parceiro em 13/11, às 14:43 (Vitor Cassara).",
      by: "Mariana Guareschi, 13/11/2026"
    }
  },
  {
    id: "JOI-360", replies: 12, team: "Simba", title: "Processo 0023249-19.2026.8.26.0050 – intimação direta a executivos do Nubank",
    prazo: "27/10/2026 (juiz deferiu 15 dias corridos)", jiraStatus: "Done", state: "ok", stateLabel: "Finalizado em 27/10",
    owner: "Aberto por Giovanna Melo · tratado pelo time Simba (Felipe Rocha)", slack: "1793023169992449", full: true,
    ticket: [
      "Chegou, pelos correios e com recebimento em 22/10, um ofício que cita multa e menciona uma executiva do Nu.",
      "O caso está cadastrado na cabine com o ID 337125. Em comentário, Dulce Cosmo registra que a solicitação foi tratada pelo time Simba."
    ],
    steps: [
      { when: "26/10 · 10:59", text: "O caso entra como reiteração, com prazo de 27/10." },
      { when: "26/10 · 11:07", text: "Mariana Guareschi acredita que a demanda é do time de Simba e aciona o grupo." },
      { when: "26/10 · 11:48", text: "Felipe Rocha puxa o ID: trata-se de notificação sobre um atendimento Simba já feito via CCS (Sisbajud) dentro do prazo legal." },
      { when: "26/10 · 11:49", text: "Mariana pede que o retorno enviado à autoridade seja trazido para validação e para as métricas de OID, por haver ameaça e intimação direta." },
      { when: "26/10 · 11:59", text: "Felipe alerta que o prazo cadastrado (5 dias) diverge do prazo deferido pelo juiz (15 dias corridos)." },
      { when: "26/10 · 16:26", text: "Felipe compartilha a carta e o histórico: ordem via Sisbajud em jan/2026 cumprida integralmente; ciência em maio/2026 com pedidos adicionais, também cumpridos; caso registrado em OID com notificação e carta precatória. Retransmitiu os dados pelo Transmissor de Documentos e retificou o número oficial do processo." },
      { when: "27/10 · 09:38", text: "Roberto Serafim conclui a análise de QA, de acordo com o histórico e a resposta." },
      { when: "27/10 · 10:09", text: "Mariana concorda com a resposta, sem gap no atendimento anterior, e sugere enviar também ao e-mail da Vara Judicial." },
      { when: "27/10 · 10:13", text: "Mariana posta o “OID finalizado”." }
    ],
    response: {
      title: "Intimação de carta precatória direcionada a executiva, com ameaça de multa, reiterando ofício já cumprido integralmente",
      resumo: "A carta precatória, direcionada a uma executiva do Nu, reitera o atendimento de um ofício de quebra de sigilo Simba, com ameaça de multa em caso de descumprimento. O ofício já havia sido integralmente cumprido.",
      gaps: ["Nenhum gap mapeado no fluxo de atendimento"],
      riscos: ["Sem risco mapeado neste primeiro momento"],
      desfecho: "Sugerido enviar o retorno também ao e-mail da Vara, além dos e-mails do Simba e da delegacia, para garantir a entrega.",
      envio: "Carta resposta elaborada pelo time Simba e validada em OID. O envio efetivo não foi registrado na thread.",
      by: "Mariana Guareschi, 27/10/2026"
    }
  },
  {
    id: "JOI-369", replies: 36, team: "LW Suits", title: "[OID] Demanda fora do padrão sobre consulta ao SCR – Lawsuits – 4008625-43.2026.8.26.0066",
    prazo: "26/11/2026", jiraStatus: "Done", state: "ok", stateLabel: "Finalizado em 23/11",
    owner: "Íris Almeida (responsável) · aberto por Amanda Macêdo", slack: "1793711653108359", full: true,
    ticket: [
      "O autor, que não é cliente ativo do Nubank (no BO consta apenas como “Convidado”), reclama que foram feitas 33 consultas ao SCR sobre ele sem autorização.",
      "Cronologia: de 20/06/2023 a 08/12/2025, alegadas 33 consultas ao histórico de crédito, incluindo acessos à noite e vários simultâneos em 20/06/2023. Em 09/08/2026 ele reclamou no Procon-SP pelo consumidor.gov e pediu as autorizações, os usuários que acessaram e a revogação. Em 10/08 a Ouvidoria respondeu de forma geral, sem explicar o motivo das consultas. Em 31/08 a reclamação foi encerrada sem solução. Em 26/10 a ação foi distribuída na 1ª Vara Cível de Barretos/SP.",
      "Comentários no ticket: em 05/11 Íris Almeida informa que está verificando; em 23/11 informa que o dossiê foi finalizado e pede para anexá-lo no e-law."
    ],
    steps: [
      { when: "03/11 · 10:14", text: "O caso entra como ofício fora do padrão, com prazo de 26/11. Mariana Guareschi aciona o grupo de Lawsuits." },
      { when: "05/11", text: "Íris Almeida avisa que acionou times externos e a tratativa pode demorar. Tamily Mascarenhas (QA) diz que aguarda o parecer de Lawsuits." },
      { when: "11/11 · 18:15", text: "Íris diz que, com a especialista de SCR, não há mais evidências: não existe histórico de consultas do lado do Nu nem motivação para as 30 e poucas consultas. Compartilha a pasta do dossiê." },
      { when: "12/11 · 09:05", text: "A análise considerou Nu Pagamentos e Nu Financeira. Não é possível extrair extrato de consultas." },
      { when: "12/11 · 11:11", text: "Mariana levanta a hipótese de as consultas terem ocorrido numa tentativa de abrir conta, com autorização do usuário. Uma busca no Glean indica que há registros técnicos de autorização." },
      { when: "12/11 · 11:43", text: "Íris abre ticket com a engenharia. Às 14:43 Mariana registra a thread aberta com os times envolvidos." },
      { when: "12/11 · 15:04", text: "Íris diz que falta explicar por que houve 33 consultas, já que a autorização inicial seria plausível mas a repetição em anos diferentes é estranha." },
      { when: "12/11 · 15:29", text: "Tamily analisa a inicial: o autor juntou os dados numa planilha comum, as consultas se espalham por 2 anos e 5 meses, não parece haver limitação regulatória e presumir incidente de segurança é um salto lógico. Ele parece preparar uma ação indenizatória." },
      { when: "13/11 · 17:05", text: "Orientação de Legal: estruturar no dossiê a jornada do autor, com prints, evidências de aceite da Política de Privacidade e o documento da política. Falta esclarecer se os acessos foram manuais ou automatizados (processo de republicação de crédito)." },
      { when: "17/11", text: "Íris decide seguir com a informação disponível e entrega o dossiê v2, com “novo” e “atualizado” marcados. Tamily o considera consistente." },
      { when: "18/11 · 09:16", text: "Mariana avalia o dossiê como muito bom, ajusta termos técnicos internos e o envia a Legal para validação final. Registra sugestões para casos atípicos: esgotar as possibilidades de retorno e buscar o PM do produto." },
      { when: "19/11 · 10:32", text: "Mariana posta o “OID Finalizado”. Íris aguarda o ok de Legal antes de concluir." },
      { when: "23/11 · 11:29", text: "Íris informa que o dossiê está finalizado e pede para anexá-lo no e-law." }
    ],
    response: {
      title: "Dossiê de defesa em ação de antecipação de provas – prospect alega consultas indevidas ao SCR e quebra de sigilo",
      resumo: "O prospect move ação de antecipação de provas contra o Nu, alegando buscas no SCR sem autorização. Depois de extensa apuração, identificou-se que a pessoa iniciou a abertura de conta e autorizou a consulta ao SCR, mas não concluiu o processo. A evidência só foi localizada ao escalar a um ponto focal de produto (PM), porque o retorno inicial por ticket foi negativo.",
      gaps: [
        "Nenhum gap de execução mapeado",
        "Oportunidade de melhoria: o retorno negativo em ticket não esclareceu os fatos, e a evidência dependeu de o time buscar o PM por iniciativa própria"
      ],
      riscos: ["Médio: a evidência da autorização depende de busca manual e de conhecimento individual (PM), com risco de não ser localizada em casos semelhantes e de o Nu perder a defesa por falta de prova"],
      boas: ["Esgotar as possibilidades de retorno: diante de uma resposta negativa, buscar o PM ou ponto focal do produto para esclarecer os fatos e entrar no mérito"],
      envio: "Dossiê finalizado em 23/11 (Íris Almeida), com pasta compartilhada no ticket para anexar no e-law.",
      by: "Mariana Guareschi, 19/11/2026"
    }
  }
];
var BASE_CASES = CASES.slice();
var BASE_PLANS = {
  "JOI-395": {
    causa: "As recusas por CNPJ inválido não buscaram a empresa por outro identificador (o CPF da representante) e não houve conferência entre pessoa física e jurídica antes do envio. Isso levou a dois envios com dados da pessoa errada e ao TC 851/2026.",
    acoes: [
      "JOI-395: acompanhar com o escritório criminal parceiro a troca da oitiva por petição de esclarecimentos e, se aceita, o pedido de arquivamento do termo circunstanciado. Responsável sugerido: Strategic Defense e escritório parceiro.",
      "JOI-395: registrar no dossiê os dois envios com dados da pessoa física (24/07 e 15/10) e verificar com Legal e Privacidade se é preciso tratar a exposição indevida. Responsável sugerido: Legal.",
      "JOI-395: usar o caso como exemplo para OOS e analistas, com o passo a passo correto de localização da PJ pelo CPF da representante. Responsável sugerido: OOS."
    ],
    prevencao: [
      "Criar checklist obrigatório de conferência do titular (PF x PJ) antes de qualquer envio, com registro no ticket. Responsável sugerido: OOS e Qualidade.",
      "Na triagem, só aceitar recusa por CNPJ inválido depois de busca por identificador alternativo, também registrada. Responsável sugerido: OOS.",
      "Gerar alerta quando chegar ofício repetido sobre o mesmo alvo, para a reiteração ser tratada com o histórico completo. Responsável sugerido: Produto e Engenharia."
    ],
    indicador: "Percentual de ofícios com conferência PF x PJ registrada e número de reiterações por alvo."
  },
  "JOI-397": {
    causa: "A triagem inicial leu mal o escopo da ordem: o juiz restringiu a quebra ao estabelecimento e o atendimento foi direcionado à cliente, sem esclarecer as compras no débito. Um ofício de 2025 ficou sem ID na cabine e sem rastreio de resposta.",
    acoes: [
      "JOI-397: concluir a carta resposta retificando o retorno anterior, com a planilha das compras no débito e a indicação da adquirente (PagSeguro). Responsável sugerido: Simba.",
      "JOI-397: enviar por e-mail às caixas indicadas no ofício e pedir ao escritório parceiro o protocolo direto nos autos. Responsável sugerido: Simba e escritório parceiro.",
      "JOI-397: investigar o ofício de 2025 sem ID na cabine e confirmar se foi respondido. Responsável sugerido: Simba.",
      "JOI-397: avaliar com Legal e Privacidade o envio indevido de dados da cliente (sigilo bancário e LGPD). Responsável sugerido: Legal."
    ],
    prevencao: [
      "Incluir na triagem um checklist de escopo da ordem: quem é o alvo da quebra (cliente ou estabelecimento) e quais dados foram pedidos. Responsável sugerido: Simba e OOS.",
      "Exigir segunda leitura quando o ofício restringe o alvo ou o período. Responsável sugerido: Qualidade.",
      "Cadastrar na cabine todo ofício recebido, inclusive os que chegam por correios, para ter rastreabilidade. Responsável sugerido: Simba.",
      "Padronizar a carta que direciona o juízo à adquirente em compras no débito. Responsável sugerido: Strategic Defense."
    ],
    indicador: "Ofícios com escopo conferido na triagem e ofícios sem ID na cabine."
  },
  "JOI-396": {
    causa: "Caso de fraude SISBAJUD tratado em fluxo especial, com condução próxima de Legal e do escritório parceiro. O dossiê ainda está em elaboração.",
    acoes: [
      "JOI-396: concluir o dossiê dentro do prazo de 02/12, usando os dossiês de exemplo compartilhados na thread. Responsável sugerido: LW Suits.",
      "JOI-396: confirmar com Legal se o caso segue o fluxo especial e sinalizar Larissa Araujo depois da confirmação. Responsável sugerido: LW Suits e Strategic Defense.",
      "JOI-396: consolidar na linha do tempo as ordens recebidas via Sisbajud, a partir do documento compartilhado por Adriana Azevedo. Responsável sugerido: LW Suits."
    ],
    prevencao: [
      "Transformar o fluxo de fraude SISBAJUD em procedimento padrão, com gatilho de entrada, responsáveis e modelo de dossiê. Responsável sugerido: Strategic Defense e LW Suits.",
      "Criar checklist de evidências para casos de fraude SISBAJUD, para o dossiê sair completo na primeira versão. Responsável sugerido: LW Suits.",
      "Guardar este caso como referência junto aos dossiês anteriores. Responsável sugerido: LW Suits."
    ],
    indicador: "Tempo entre a abertura do ticket e o dossiê entregue, e número de casos de fraude SISBAJUD por mês."
  },
  "JOI-394": {
    causa: "Não foi mapeada falha de execução. O risco veio da sensibilidade do caso: a vítima é membro do Ministério Público, o Nu foi incluído por engano no polo passivo, a conta citada não foi localizada e um ofício de 15/09 ficou sem confirmação de resposta.",
    acoes: [
      "JOI-394: acompanhar com Legal a retirada do Nu do polo passivo e guardar a prova do protocolo da resposta. Responsável sugerido: Legal.",
      "JOI-394: verificar o ofício de 15/09 sem confirmação de resposta e, se estiver pendente, responder. Responsável sugerido: OOS.",
      "JOI-394: registrar no dossiê a transferência de 12/12/25 e a recuperação de valores do Limbo, como esclarecido na resposta. Responsável sugerido: OOS."
    ],
    prevencao: [
      "Definir critério explícito para levar ao OID casos com vítima ligada a autoridade pública ou com o Nu no polo passivo por engano. Responsável sugerido: Strategic Defense.",
      "Antes de responder, conferir a rastreabilidade de ofícios anteriores no mesmo processo. Responsável sugerido: OOS.",
      "Manter a boa prática de antecipar o prazo interno quando houver feriado e validação de Legal. Responsável sugerido: OOS."
    ],
    indicador: "Ofícios sem confirmação de resposta e casos respondidos dentro do prazo interno."
  },
  "JOI-393": {
    causa: "O caso já se enquadrava em alinhamento vigente (JOI-280, sobre CDBs do Banco Master), mas chegou ao OID por dúvida se a Operação conhecia o treinamento. Foi devolvido ao analista.",
    acoes: [
      "JOI-393: confirmar que o analista atendeu conforme o alinhamento do JOI-280 e que um IC4 validou a resposta. Responsável sugerido: Qualidade.",
      "JOI-393: conferir se a resposta explicou os seis pontos pedidos pelo juiz (cotas, prazo de liquidação, valor da cota, valores bruto e líquido e a diferença). Responsável sugerido: OOS."
    ],
    prevencao: [
      "Reforçar com a operação o treinamento sobre CDBs do Banco Master e liquidação extrajudicial. Responsável sugerido: Strategic Defense e Qualidade.",
      "Incluir na triagem um atalho para os alinhamentos vigentes, para evitar abrir OID quando já existe orientação. Responsável sugerido: OOS.",
      "Registrar os casos devolvidos por já terem alinhamento, para medir se o treinamento está funcionando. Responsável sugerido: Strategic Defense."
    ],
    indicador: "Casos devolvidos ao analista por já terem alinhamento vigente."
  },
  "JOI-392": {
    causa: "A resposta anterior trouxe informação errada sobre a natureza do ativo (fundos de investimento em vez de debêntures), possivelmente por macros e trabalho manual. A ferramenta padrão não gera o extrato histórico e o processo dependeu de RPA com D+1, do Sinacor e de um PM.",
    acoes: [
      "JOI-392: acompanhar se o juízo aceita o extrato e a explicação enviados em 16/11, e preparar nova resposta se houver terceira reiteração. Responsável sugerido: OOS.",
      "JOI-392: abrir demanda de produto e engenharia para gerar extrato histórico de debêntures desde a data do bloqueio. Responsável sugerido: Produto e Engenharia.",
      "JOI-392: registrar o contato do PM e do ponto focal usados neste caso para consultas futuras. Responsável sugerido: OOS."
    ],
    prevencao: [
      "Revisar as macros de resposta para ativos de empresas em recuperação judicial, para não afirmar o tipo de ativo sem conferir. Responsável sugerido: Strategic Defense e OOS.",
      "Exigir conferência do tipo de ativo antes de responder bloqueios sobre investimentos. Responsável sugerido: OOS.",
      "Criar fluxo de escalonamento para extrato histórico com prazo definido, sem depender de contato individual. Responsável sugerido: Produto.",
      "Manter o double-check entre o saldo do extrato e o texto da resposta antes do envio. Responsável sugerido: Qualidade."
    ],
    indicador: "Respostas retificadas por erro na natureza do ativo e tempo para obter extrato histórico."
  },
  "JOI-391": {
    causa: "Não há novo bloqueio automático quando uma transferência entre contas, feita por outro time, é estornada. Também não houve monitoramento depois da transferência, e a informação foi reiterada ao juiz sem nova validação no Tristam.",
    acoes: [
      "JOI-391: confirmar o protocolo da resposta nos autos e guardar o comprovante da conta judicial. Responsável sugerido: OOS.",
      "JOI-391: levar o gap ao próximo checkpoint de Bravo e orientar os analistas a acompanhar o processo por algumas horas depois da transferência. Responsável sugerido: OOS e Operação.",
      "JOI-391: abrir demanda de produto e engenharia para rebloqueio automático em caso de estorno de transferência entre contas. Responsável sugerido: Produto e Engenharia.",
      "JOI-391: levantar quantos casos semelhantes, com transferência entre contas e estorno, existem hoje. Responsável sugerido: Strategic Defense."
    ],
    prevencao: [
      "Criar o procedimento “validar no Tristam antes de reiterar ao juiz que a transferência foi feita”. Responsável sugerido: OOS e Qualidade.",
      "Gerar alerta de estorno em conta com bloqueio judicial recente. Responsável sugerido: Engenharia.",
      "Incluir no checklist de transferência entre contas a verificação do status final da operação. Responsável sugerido: Operação."
    ],
    indicador: "Estornos pós-transferência sem rebloqueio e respostas reiteradas sem nova validação."
  },
  "JOI-390": {
    causa: "A primeira resposta enviou extrato e ficha cadastral que o juízo não pediu, e as reiterações repetiram a negativa sem buscar os dados pelo número do processo. Faltaram escalonamento ao PM e revisão de escopo antes do envio. O dado do pagador vem da Caixa no arquivo ADDA108.",
    acoes: [
      "JOI-390: acompanhar com Legal a decisão sobre a multa de 5% e o risco de chegar a 20%, usando a resposta de 13/11. Responsável sugerido: Legal e Strategic Defense.",
      "JOI-390: juntar ao dossiê os protocolos e o e-mail enviados à autoridade. Responsável sugerido: OOS.",
      "JOI-390: avaliar, com Legal e Privacidade, o envio de extrato e ficha cadastral fora do escopo pedido. Responsável sugerido: Legal."
    ],
    prevencao: [
      "Orientar a operação sobre minimização: enviar só o que o juízo pediu. Responsável sugerido: Strategic Defense e Qualidade.",
      "Nas reiterações, fazer nova busca pelo número do processo antes de repetir uma negativa. Responsável sugerido: OOS.",
      "Criar fluxo de escalonamento ao PM para dúvidas de produto (boletos, ADDA108), com responsável e prazo. Responsável sugerido: Produto.",
      "Publicar material curto sobre como o pagador de boleto pago em lotérica ou correspondente aparece no ADDA108. Responsável sugerido: Strategic Defense."
    ],
    indicador: "Reiterações respondidas com negativa repetida e envios com dados além do escopo."
  },
  "JOI-360": {
    causa: "Não houve gap no atendimento: a ordem já tinha sido cumprida via Sisbajud. O risco foi a intimação direta de uma executiva e a divergência entre o prazo cadastrado (5 dias) e o deferido pelo juiz (15 dias corridos).",
    acoes: [
      "JOI-360: confirmar o envio da carta resposta ao juízo e o envio também ao e-mail da Vara, além dos e-mails do Simba e da delegacia. Responsável sugerido: Simba.",
      "JOI-360: corrigir na cabine o prazo para 15 dias corridos, conforme deferido pelo juiz. Responsável sugerido: Simba.",
      "JOI-360: guardar a retransmissão pelo Transmissor de Documentos como prova de cumprimento. Responsável sugerido: Simba."
    ],
    prevencao: [
      "Conferir na triagem o prazo deferido pelo juiz contra o prazo cadastrado. Responsável sugerido: OOS e Simba.",
      "Padronizar o envio das respostas também ao e-mail da Vara para garantir a entrega. Responsável sugerido: Simba.",
      "Tratar com prioridade máxima ofícios que mencionam executivos, conforme o alinhamento do JOI-256. Responsável sugerido: OOS."
    ],
    indicador: "Divergências entre prazo cadastrado e prazo deferido e ofícios com menção a executivos tratados dentro do prazo."
  },
  "JOI-369": {
    causa: "O retorno negativo do ticket não esclareceu os fatos e a evidência de autorização do SCR só apareceu ao escalar a um PM. Não há como o time puxar um extrato das consultas, e as 33 consultas ao longo de 2 anos e 5 meses ainda não têm explicação.",
    acoes: [
      "JOI-369: anexar o dossiê no e-law e enviar ao escritório parceiro, como pedido por Íris Almeida em 23/11. Responsável sugerido: LW Suits e analista do caso.",
      "JOI-369: acompanhar a resposta da engenharia no GCSES-1498 sobre os registros de autorização e atualizar o dossiê se houver novidade. Responsável sugerido: LW Suits.",
      "JOI-369: esclarecer no dossiê se as consultas foram manuais ou automatizadas (processo de republicação de crédito) no período. Responsável sugerido: LW Suits e Produto."
    ],
    prevencao: [
      "Criar guia interno para localizar evidência de autorização de consulta ao SCR (serviço Geller, campo de aceite do prospect e logs no Alexandria). Responsável sugerido: LW Suits e Produto.",
      "Orientar: quando um ticket voltar negativo, buscar o PM ou ponto focal do produto, usando Glean ou NuSpot para achar o responsável. Responsável sugerido: Strategic Defense.",
      "Avaliar uma consulta de histórico de consultas ao SCR por CPF para uso em defesas. Responsável sugerido: Produto e Engenharia."
    ],
    indicador: "Tempo para localizar a evidência de autorização e tickets negativos escalados ao PM."
  }
};
BASE_CASES.forEach(function (c) { c.plano = BASE_PLANS[c.id] || null; });

var TEAMS = ["OOS", "Simba", "LW Suits"];
var HINTS = {
  "OOS": "Casos direcionados ao grupo @oos-oid: sanção aplicada, reiteração e ofícios fora do padrão.",
  "Simba": "Casos assumidos pelo time de Simba (por exemplo, Felipe Rocha) na thread.",
  "LW Suits": "Casos conduzidos pelo time de Lawsuits Defense (por exemplo, Lívia Zaroni e Íris Almeida).",
  "Resposta enviada": "Texto de encerramento postado na thread (“OID Finalizado”) e, quando existir, o documento enviado ao juízo."
};
var RESP = "Resposta enviada";
var active = "OOS";
var respFilter = "Todos";
var open = {};

function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
function hl(s, q) {
  var t = esc(s);
  if (!q) return t;
  var re = new RegExp("(" + q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "gi");
  return t.replace(re, "<mark>$1</mark>");
}
function blob(c) {
  var parts = [c.id, c.team, c.title, c.owner, c.stateLabel];
  (c.ticket || []).forEach(function (x) { parts.push(x); });
  (c.steps || []).forEach(function (s) { parts.push(s.text); });
  if (c.response) {
    var r = c.response;
    parts.push(r.title, r.resumo, r.desfecho || '', r.envio || '');
    (r.boas || []).forEach(function (x) { parts.push(x); });
    (r.gaps || []).concat(r.riscos || []).forEach(function (x) { parts.push(x); });
  }
  var od = openDate(c);
  if (od) parts.push(pad2(od.getDate()) + "/" + pad2(od.getMonth() + 1) + "/" + od.getFullYear(), od.getFullYear() + "-" + pad2(od.getMonth() + 1) + "-" + pad2(od.getDate()));
  parts.push(c.prazo || "");
  var pm = String(c.prazo || "").match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (pm) parts.push(pm[3] + "-" + pm[2] + "-" + pm[1]);
  (c.steps || []).forEach(function (s) { parts.push(s.when); });
  if (c.plano) { parts.push(c.plano.causa, c.plano.acoes.join(" "), c.plano.prevencao.join(" ")); }
  return parts.join(" ").toLowerCase();
}
function openDate(c) {
  var s = String(c.slack || "");
  if (!/^\d{16}$/.test(s)) return null;
  return new Date(parseInt(s.slice(0, 10), 10) * 1000);
}
function pad2(n) { return (n < 10 ? "0" : "") + n; }
function monthKey(c) { var d = openDate(c); return d ? d.getFullYear() + "-" + pad2(d.getMonth() + 1) : ""; }
function monthLabel(k) {
  var p = k.split("-");
  var t = new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  return t.charAt(0).toUpperCase() + t.slice(1);
}
function openedSpan(c) {
  var d = openDate(c);
  return d ? "<span>Aberto em " + pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + "</span>" : "";
}
function curMonth() { var el = document.getElementById("month"); return el ? el.value : ""; }
var monthSig = "";
function fillMonths() {
  var el = document.getElementById("month");
  if (!el) return;
  var cnt = {};
  CASES.forEach(function (c) { var k = monthKey(c); if (k) cnt[k] = (cnt[k] || 0) + 1; });
  var keys = Object.keys(cnt).sort().reverse();
  var sg = keys.map(function (k) { return k + ":" + cnt[k]; }).join("|");
  if (sg === monthSig) return;
  var cur = el.value; monthSig = sg;
  el.innerHTML = '<option value="">Todos os meses</option>' + keys.map(function (k) {
    return '<option value="' + k + '">' + esc(monthLabel(k)) + " (" + cnt[k] + ")</option>";
  }).join("");
  el.value = keys.indexOf(cur) >= 0 ? cur : "";
}
function matches(c, q) {
  var m = curMonth();
  if (m && monthKey(c) !== m) return false;
  if (!q) return true;
  var qq = q.toLowerCase().replace(/^(\d{1,2})[-.](\d{1,2})(?:[-.](\d{2,4}))?$/, function (_, d, mo, y) { return d + "/" + mo + (y ? "/" + y : ""); });
  return blob(c).indexOf(qq) !== -1;
}

function renderTabs(q) {
  var el = document.getElementById("tabs");
  var html = "";
  TEAMS.forEach(function (t) {
    var n = CASES.filter(function (c) { return c.team === t && matches(c, q); }).length;
    html += '<button class="tab" role="tab" data-tab="' + t + '" aria-selected="' + (active === t) + '">' + t + '<span class="count">' + n + "</span></button>";
  });
  var rn = CASES.filter(function (c) { return c.response && matches(c, q); }).length;
  html += '<button class="tab" role="tab" data-tab="' + RESP + '" aria-selected="' + (active === RESP) + '">' + RESP + '<span class="count">' + rn + "</span></button>";
  var pn = CASES.filter(function (c) { return c.plano; }).length;
  html += '<button class="tab" role="tab" data-tab="' + PLAN + '" aria-selected="' + (active === PLAN) + '">' + PLAN + '<span class="count">' + pn + "</span></button>";
  el.innerHTML = html;
}

function caseHtml(c, q) {
  var isOpen = !!open[c.id] || (q && c.full);
  var h = '<div class="case' + (isOpen ? " open" : "") + '" data-id="' + c.id + '">';
  h += '<button class="case-head" aria-expanded="' + isOpen + '" data-toggle="' + c.id + '">';
  h += '<div><div class="case-title">' + hl(c.id, q) + " · " + hl(c.title, q) + "</div>";
  h += '<div class="case-meta"><span>Prazo ' + esc(c.prazo) + "</span>" + openedSpan(c) + "<span>" + hl(c.owner, q) + "</span></div></div>";
  h += '<span class="chip ' + c.state + '">' + esc(c.stateLabel) + "</span></button>";
  h += '<div class="case-body">';
  h += '<div class="links"><a href="' + JIRA + c.id + '" target="_blank" rel="noopener">Abrir ticket no Jira</a><a href="' + SLACK + c.slack + '" target="_blank" rel="noopener">Abrir thread no Slack</a></div>';
  if (c.full) {
    h += '<div class="cols"><div><h3>O que o analista registrou no ticket</h3>';
    c.ticket.forEach(function (p) { h += "<p>" + hl(p, q) + "</p>"; });
    h += '</div><div><h3>Passo a passo</h3><ol class="steps">';
    c.steps.forEach(function (s) { h += '<li><span class="when">' + esc(s.when) + "</span>" + hl(s.text, q) + "</li>"; });
    h += "</ol></div></div>";
    if (!c.response) h += '<p class="note">Ainda sem resposta enviada: o caso segue em andamento.</p>';
    if (c.plano) h += planInline(c.plano);
  } else {
    h += '<p class="pending">O resumo do ticket, o passo a passo e a resposta deste caso serão gerados na próxima atualização. Clique em Atualizar no topo da página. A classificação por time também é confirmada nessa leitura.</p>';
  }
  h += "</div></div>";
  return h;
}

function listHtml(arr) {
  if (!arr || !arr.length) return "";
  return "<ul>" + arr.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>";
}

function respHtml(c) {
  var r = c.response;
  var h = '<article class="resp-item resp"><div class="resp-top"><h2>' + esc(c.id) + " · " + esc(c.team) + '</h2><span class="who">' + esc(r.by) + "</span></div>";
  h += '<div class="resp-text"><p><strong>' + esc(r.title) + "</strong></p>";
  h += '<span class="lbl">Resumo</span><p>' + esc(r.resumo) + "</p>";
  h += '<span class="lbl">Gaps mapeados</span>' + listHtml(r.gaps);
  h += '<span class="lbl">Riscos mapeados</span>' + listHtml(r.riscos);
  if (r.desfecho) h += '<span class="lbl">Desfecho</span><p>' + esc(r.desfecho) + "</p>";
  if (r.boas) h += '<span class="lbl">Boas práticas</span>' + listHtml(r.boas);
  if (r.envio) h += '<span class="lbl">Envio da resposta</span><p>' + esc(r.envio) + "</p>";
  h += "</div>";
  h += '<div class="links"><a href="' + JIRA + c.id + '" target="_blank" rel="noopener">Ticket no Jira</a><a href="' + SLACK + c.slack + '" target="_blank" rel="noopener">Thread no Slack</a>';
  if (r.extra && /^https:\/\//.test(r.extra.url)) h += '<a href="' + esc(r.extra.url) + '" target="_blank" rel="noopener">' + esc(r.extra.label) + "</a>";
  h += "</div></article>";
  return h;
}

function render() {
  fillMonths();
  var q = document.getElementById("q").value.trim();
  renderTabs(q);
  var mSel = curMonth();
  document.getElementById("hint").textContent = HINTS[active] + (mSel ? " Mostrando só casos abertos em " + monthLabel(mSel) + "." : "");
  var p = document.getElementById("panel");
  var h = "";
  if (active === PLAN) { p.innerHTML = planView(q); return; }
  if (active === RESP) {
    h += '<div class="filters" id="filters">';
    ["Todos"].concat(TEAMS).forEach(function (t) {
      h += '<button data-filter="' + t + '" aria-pressed="' + (respFilter === t) + '">' + t + "</button>";
    });
    h += "</div>";
    var rows = CASES.filter(function (c) { return c.response && matches(c, q) && (respFilter === "Todos" || c.team === respFilter); }).sort(function (a, b) { return num(b.id) - num(a.id); });
    if (!rows.length) h += '<p class="empty">Nenhuma resposta encontrada para esse filtro.</p>';
    rows.forEach(function (c) { h += respHtml(c); });
  } else {
    var items = CASES.filter(function (c) { return c.team === active && matches(c, q); }).sort(function (a, b) { return num(b.id) - num(a.id); });
    h += '<div class="list">';
    if (!items.length) h += '<p class="empty">Nenhum caso encontrado nesta aba.</p>';
    items.forEach(function (c) { h += caseHtml(c, q); });
    h += "</div>";
  }
  p.innerHTML = h;
}

document.getElementById("tabs").addEventListener("click", function (e) {
  var b = e.target.closest("[data-tab]");
  if (b) { active = b.getAttribute("data-tab"); render(); }
});
document.getElementById("panel").addEventListener("click", function (e) {
  var t = e.target.closest("[data-toggle]");
  if (t) { var id = t.getAttribute("data-toggle"); open[id] = !open[id]; render(); return; }
  var f = e.target.closest("[data-filter]");
  if (f) { respFilter = f.getAttribute("data-filter"); render(); return; }
  var a = e.target.closest("[data-act]");
  if (a && !a.disabled) {
    var k = a.getAttribute("data-act");
    if (k === "gen-missing") genMissing(); else if (k === "gen-plan") genConsolidated();
    return;
  }
  var g = e.target.closest("[data-goto]");
  if (g) goToCase(g.getAttribute("data-goto"));
});
document.getElementById("q").addEventListener("input", render);
document.getElementById("month").addEventListener("change", render);

/* ---------- Tema: um botão com sol e lua ---------- */
var SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
var MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
var REFRESH_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/></svg>';

function currentTheme() {
  var t = document.documentElement.getAttribute("data-theme");
  if (t) return t;
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function paintTheme() {
  var t = currentTheme();
  var b = document.getElementById("theme-toggle");
  /* mostra o ícone do tema para o qual o clique leva */
  b.innerHTML = t === "dark" ? SUN : MOON;
  b.setAttribute("aria-label", t === "dark" ? "Mudar para tela clara" : "Mudar para tela escura");
  b.setAttribute("title", t === "dark" ? "Mudar para tela clara" : "Mudar para tela escura");
}
function setTheme(t, save) {
  document.documentElement.setAttribute("data-theme", t);
  if (save) { try { localStorage.setItem("oid-theme", t); } catch (e) {} }
  paintTheme();
}
document.getElementById("theme-toggle").addEventListener("click", function () {
  setTheme(currentTheme() === "dark" ? "light" : "dark", true);
});
(function () {
  var saved = null;
  try { saved = localStorage.getItem("oid-theme"); } catch (e) {}
  if (saved === "light" || saved === "dark") document.documentElement.setAttribute("data-theme", saved);
  paintTheme();
})();

/* ---------- Atualizar: lê Slack e Jira e grava para todos ---------- */
var CHANNEL = "C0A0EC24DJ6";
var SLACK_SRV = "Slack";
var JIRA_SRV = "Atlassian";
var CLOUD = "nubank.atlassian.net";
var MAX_PER_RUN = 4;
var TEAM_LIST = ["OOS", "Simba", "LW Suits"];
var mcp = null, sample = null, db = null, busy = false, syncAt = null, REMOTE = {};
var tabId = "t" + Math.random().toString(36).slice(2, 10);
var slowTimer = null, slowShown = false;

function setStatus(msg, kind) {
  var el = document.getElementById("status");
  el.textContent = msg || "";
  el.className = "status" + (kind === "err" ? " err" : "");
}
function paintRefresh(isBusy) {
  var b = document.getElementById("refresh");
  b.disabled = !!isBusy || b.getAttribute("data-off") === "1";
  b.className = "btn-band" + (isBusy ? " spin" : "");
  document.getElementById("refresh-label").textContent = isBusy ? "Atualizando…" : "Atualizar";
  document.getElementById("stop").hidden = !isBusy;
  if (typeof PLAN !== "undefined" && active === PLAN) render();
}
function disableRefresh() {
  var b = document.getElementById("refresh");
  b.setAttribute("data-off", "1"); b.disabled = true;
}
function errMessage(e) {
  var c = e && e.code, s = (e && e.server) || "";
  switch (c) {
    case "server_not_connected":
      return "O conector " + (s || "necessário") + " não está conectado na sua conta. Adicione em claude.ai, Configurações, Conectores, e atualize de novo.";
    case "needs_reauth":
      return "A conexão com " + (s || "o conector") + " expirou. Reconecte em claude.ai, Configurações, Conectores.";
    case "selection_required":
      return "Há mais de uma conexão chamada " + (s || "igual") + ". Escolha qual usar quando o claude.ai pedir e atualize de novo.";
    case "not_granted": case "approval_required": case "consent_required":
      return s ? "A permissão para acessar " + s + " não foi dada. Atualize de novo e permita quando o claude.ai perguntar."
               : "A permissão para usar o Claude no resumo não foi dada. Atualize de novo e permita quando for solicitado.";
    case "blocked_by_policy":
      return "A política da sua organização bloqueia o acesso a " + (s || "esse conector") + " por esta página.";
    case "not_in_manifest":
      return "Esta página ainda não tem permissão para essa ferramenta do " + (s || "conector") + ".";
    case "rate_limited": case "resource_exhausted":
      return "Muitas chamadas seguidas. Aguarde um instante e atualize de novo.";
    case "server_unavailable": case "upstream_error": case "unavailable":
      return "O " + (s || "serviço") + " não respondeu. Tente atualizar de novo em instantes.";
    case "tool_error":
      return "O " + (s || "conector") + " retornou um erro: " + String(e.message || "").slice(0, 160);
    case "invalid_argument":
      return "Seu acesso a esta página é só de leitura, então não dá para gravar a atualização. Peça o nível de Colaborador no compartilhamento.";
    case "quota_exceeded":
      return "O limite de armazenamento da página foi atingido. Avise quem administra a ferramenta.";
    case "revoked":
      return "Seu acesso à página mudou. Recarregue a página.";
    case "cancelled":
      return "Atualização cancelada.";
    default:
      return "Não foi possível atualizar (" + (c || "erro") + ").";
  }
}
function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
/* leitura com no máximo uma nova tentativa quando o erro é marcado como retryable */
async function call(server, tool, input) {
  try {
    return await mcp.callTool(server, tool, input, { cache: { refresh: true } });
  } catch (e) {
    if (e && e.retryable) {
      await wait(Math.min(e.retryAfterMs || 1500, 5000) + Math.random() * 500);
      return await mcp.callTool(server, tool, input, { cache: { refresh: true } });
    }
    throw e;
  }
}
function asText(r) {
  var p = r && r.payload;
  if (p && typeof p === "object" && typeof p.messages === "string") return p.messages;
  if (typeof p === "string") return p;
  if (p != null) return JSON.stringify(p);
  return ((r && r.content) || []).map(function (b) { return b.text || ""; }).join("\n");
}
function asObject(r) {
  var p = r && r.payload;
  if (typeof p === "string") { try { p = JSON.parse(p); } catch (e) { p = null; } }
  return p && typeof p === "object" ? p : {};
}
function jiraBrief(r) {
  var p = asObject(r), f = p.fields || {};
  return {
    key: p.key, summary: f.summary, status: f.status && f.status.name, labels: f.labels,
    assignee: f.assignee && f.assignee.displayName, reporter: f.reporter && f.reporter.displayName,
    created: f.created, description: f.description,
    comments: ((f.comment && f.comment.comments) || []).map(function (c) {
      return { author: c.author && c.author.displayName, created: c.created, body: c.body };
    })
  };
}
function unesc(x) { return String(x).replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"'); }
function parseChannel(text) {
  var out = [], seen = {};
  text.split(/=== Message from /).slice(1).forEach(function (b) {
    var ts = (b.match(/Message TS: (\d+\.\d+)/) || [])[1];
    var jm = b.match(/browse\/(JOI-\d+)(?:\|([^>]*))?>/);
    if (!ts || !jm || seen[jm[1]]) return;
    if (/agora-alinhamentos|novo alinhamento/i.test(b)) return;
    var pr = b.match(/Prazo: (\d{4})-(\d{2})-(\d{2})/);
    var rp = b.match(/Thread: (\d+) replies/);
    var label = unesc(jm[2] || "").replace(/^\s*JOI-\d+\s*[-–|:]?\s*/, "").trim();
    var lw = /lawsuits-oid/.test(b) || /fraude no SISBAJUD/i.test(b);
    var kind = /lawsuits-oid/.test(b) ? "Pedido de dossiê"
      : /fraude no SISBAJUD/i.test(b) ? "Fraude SISBAJUD"
      : /reiteracao-oid/.test(b) ? "Reiteração"
      : /important_flag/.test(b) ? "Sanção aplicada"
      : /suporte-judefense-legal-oid/.test(b) ? "Ofício fora do padrão" : "Caso OID";
    seen[jm[1]] = 1;
    out.push({ id: jm[1], ts: ts, title: label || jm[1], kind: kind, team: lw ? "LW Suits" : "OOS",
      prazo: pr ? pr[3] + "/" + pr[2] + "/" + pr[1] : "", replies: rp ? parseInt(rp[1], 10) : 0 });
  });
  return out;
}
function dotTs(id) { return id.indexOf(".") >= 0 ? id : id.slice(0, -6) + "." + id.slice(-6); }
function undotTs(ts) { return String(ts).replace(".", ""); }
function num(id) { return parseInt(String(id).replace(/\D/g, ""), 10) || 0; }
function clip(s, n) { s = String(s || ""); return s.length > n ? s.slice(0, n) + "\n[…texto cortado…]" : s; }
function arr(x) { return Array.isArray(x) ? x.map(String).filter(Boolean) : []; }

function buildPrompt(id, prazo, jira, thread) {
  return "Você organiza casos do canal #operational-intelligence-desk (OID) para uma página de consulta. " +
    "Responda SOMENTE com um objeto JSON válido, sem texto antes ou depois e sem crases.\n\n" +
    "REGRAS\n" +
    "- Escreva em português do Brasil, com suas próprias palavras (resuma, sem copiar trechos longos).\n" +
    "- Não inclua CPF, CNPJ de pessoa física, número de conta ou outros dados bancários pessoais. Números de processo e de tickets podem ficar.\n" +
    "- team: \"OOS\" por padrão (casos direcionados ao grupo @oos-oid). Use \"Simba\" se o time de Simba (por exemplo Felipe Rocha) assumiu ou tratou o caso na thread. Use \"LW Suits\" se o time de Lawsuits Defense (por exemplo Íris Almeida ou Lívia Zaroni) conduz o caso ou elabora o dossiê.\n" +
    "- ticket: 2 a 4 parágrafos curtos resumindo o que o analista escreveu no ticket do Jira (descrição e comentários).\n" +
    "- steps: o passo a passo da thread em ordem cronológica. Cada item tem when no formato \"dd/mm · hh:mm\" (horário de Brasília) e text com uma ou duas frases dizendo quem fez o quê. Agrupe mensagens triviais.\n" +
    "- response: preencha SOMENTE se a thread tiver uma mensagem de encerramento (“OID Finalizado”). Campos: title, resumo, gaps (lista), riscos (lista), boas (lista, opcional), desfecho (opcional), envio (texto dizendo se, quando e por quem a resposta foi enviada, se a thread disser; senão omita) e by (\"Nome, dd/mm/aaaa\" de quem postou o encerramento). Sem encerramento, response deve ser null.\n" +
    "- state: \"ok\" se o caso foi finalizado ou devolvido ao analista; senão \"wip\". stateLabel: \"Finalizado em dd/mm\", \"Devolvido ao analista\" ou \"Em andamento\".\n" +
    "- owner: \"Aberto por X · responsável: Y\" (omita o que não souber).\n" +
    "- title: título curto do caso (pode usar o do Jira).\n" +
    "- plano: sugestão de plano de ação. Campos: causa (causa provável, 1 ou 2 frases), acoes (3 a 5 ações para tratar o caso, cada uma citando o ticket " + id + " e terminando com \"Responsável sugerido: X\"), prevencao (3 a 4 medidas para evitar que outros casos iguais aconteçam, cada uma com \"Responsável sugerido: X\") e indicador (uma frase sobre como acompanhar).\n\n" +
    "FORMATO\n{\"team\":\"OOS\",\"title\":\"\",\"state\":\"wip\",\"stateLabel\":\"\",\"owner\":\"\",\"ticket\":[\"\"],\"steps\":[{\"when\":\"\",\"text\":\"\"}],\"response\":null,\"plano\":{\"causa\":\"\",\"acoes\":[\"\"],\"prevencao\":[\"\"],\"indicador\":\"\"}}\n\n" +
    "CASO: " + id + "\nPRAZO NO CANAL: " + (prazo || "não informado") + "\n\n" +
    "TICKET NO JIRA (JSON):\n" + clip(JSON.stringify(jira), 12000) + "\n\n" +
    "THREAD DO SLACK:\n" + clip(thread, 40000);
}

/* Todo dado vindo do banco ou do Claude passa por aqui antes de ser exibido */
function cleanCase(id, d) {
  if (!/^JOI-\d+$/.test(String(id)) || !d || typeof d !== "object") return null;
  var steps = Array.isArray(d.steps) ? d.steps.map(function (s) {
    return { when: String((s && s.when) || ""), text: String((s && s.text) || "") };
  }).filter(function (s) { return s.text; }) : [];
  var resp = null;
  if (d.response && typeof d.response === "object") {
    var r = d.response;
    resp = { title: String(r.title || ""), resumo: String(r.resumo || ""), gaps: arr(r.gaps), riscos: arr(r.riscos), by: String(r.by || "") };
    if (arr(r.boas).length) resp.boas = arr(r.boas);
    if (r.desfecho) resp.desfecho = String(r.desfecho);
    if (r.envio) resp.envio = String(r.envio);
  }
  var state = ["ok", "wip", "todo"].indexOf(d.state) >= 0 ? d.state : "wip";
  return {
    id: String(id),
    team: TEAM_LIST.indexOf(d.team) >= 0 ? d.team : "OOS",
    title: String(d.title || id),
    prazo: String(d.prazo || "—"),
    jiraStatus: String(d.jiraStatus || "—"),
    state: state,
    stateLabel: String(d.stateLabel || (state === "ok" ? "Finalizado" : "Em andamento")),
    owner: String(d.owner || ""),
    slack: /^\d{16}$/.test(String(d.slack)) ? String(d.slack) : "",
    full: true,
    ticket: arr(d.ticket),
    steps: steps,
    response: resp,
    plano: cleanPlan(d.plano),
    replies: typeof d.replies === "number" ? d.replies : undefined
  };
}
function toDoc(c) { return JSON.parse(JSON.stringify(c)); }

function cleanItem(it) {
  if (!it || typeof it !== "object") return null;
  if (!/^JOI-\d+$/.test(String(it.id)) || !/^\d+\.\d+$/.test(String(it.ts))) return null;
  return {
    id: String(it.id), ts: String(it.ts), title: String(it.title || it.id).slice(0, 300),
    kind: String(it.kind || "Caso OID").slice(0, 60), team: TEAM_LIST.indexOf(it.team) >= 0 ? it.team : "OOS", prazo: String(it.prazo || "").slice(0, 20),
    replies: typeof it.replies === "number" ? it.replies : 0
  };
}
function stubCase(it) {
  var i = cleanItem(it);
  if (!i) return null;
  return {
    id: i.id, team: i.team, title: i.title, prazo: i.prazo || "—", jiraStatus: "—",
    state: "todo", stateLabel: "Aguardando leitura",
    owner: i.kind + " · " + i.replies + " respostas na thread · classificação provisória",
    slack: undotTs(i.ts), full: false, replies: i.replies
  };
}
function sig(items) {
  return items.map(function (i) { return i.id + ":" + i.replies + ":" + i.title + ":" + i.kind + ":" + i.team; }).join("|");
}
var INDEX = [], INDEX_SIG = "", stopRequested = false;

function rebuild() {
  var m = {};
  INDEX.forEach(function (it) { var c = stubCase(it); if (c) m[c.id] = c; });
  BASE_CASES.forEach(function (c) { m[c.id] = c; });
  Object.keys(REMOTE).forEach(function (id) { m[id] = REMOTE[id]; });
  CASES = Object.keys(m).map(function (k) { return m[k]; });
  render(); updateSnap();
}
function updateSnap() {
  var by = { "OOS": 0, "Simba": 0, "LW Suits": 0 }, read = 0;
  CASES.forEach(function (c) { if (c.full) { read++; by[c.team] = (by[c.team] || 0) + 1; } });
  var head = syncAt
    ? "Atualizado em " + new Date(syncAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })
    : "Dados de 23/11/2026";
  document.getElementById("snap").textContent = head + " · " + CASES.length + " casos, " + read + " com resumo" +
    (read ? " (" + by["OOS"] + " OOS, " + by["Simba"] + " Simba, " + by["LW Suits"] + " LW Suits)." : ".");
}
function subscribe() {
  slowTimer = setTimeout(function () {
    slowShown = true;
    setStatus("Ainda não consegui carregar os casos compartilhados. Mostrando os que vieram com a página.");
  }, 10000);
  db.collection("cases").onSnapshot(function (snap) {
    if (!snap.metadata.fromCache) {
      clearTimeout(slowTimer);
      if (slowShown) { slowShown = false; setStatus(""); }
    }
    var r = {};
    snap.docs.forEach(function (d) { var c = cleanCase(d.id, d.data()); if (c) r[c.id] = c; });
    REMOTE = r; rebuild();
  }, function (e) { clearTimeout(slowTimer); setStatus(errMessage(e), "err"); });
  db.doc("meta/index").onSnapshot(function (s) {
    var d = s.exists ? s.data() : null;
    INDEX = d && Array.isArray(d.items) ? d.items.map(cleanItem).filter(Boolean) : [];
    INDEX_SIG = sig(INDEX);
    rebuild();
  }, function () {});
  db.doc("meta/plan").onSnapshot(function (s) {
    PLAN_DOC = s.exists ? cleanPlanDoc(s.data()) : null;
    render();
  }, function () {});
  db.doc("meta/sync").onSnapshot(function (s) {
    var d = s.exists ? s.data() : null;
    syncAt = d && typeof d.at === "number" ? d.at : null;
    updateSnap();
  }, function () {});
}

function pageCursor(r) {
  var p = r && r.payload, txt = "";
  if (p && typeof p === "object" && p.pagination_info) txt = String(p.pagination_info);
  else if (typeof p === "string") txt = p;
  else txt = ((r && r.content) || []).map(function (b) { return b.text || ""; }).join("\n");
  var m = txt.match(/cursor:\s*`([^`]+)`/);
  return m ? m[1] : null;
}
async function readWholeChannel() {
  var all = [], seen = {}, cursor = null;
  for (var page = 1; page <= 40; page++) {
    setStatus("Lendo o canal no Slack, desde a abertura (página " + page + ")…");
    var input = { channel_id: CHANNEL, limit: 100, response_format: "detailed" };
    if (cursor) input.cursor = cursor;
    var r = await call(SLACK_SRV, "slack_read_channel", input);
    parseChannel(asText(r)).forEach(function (f) {
      if (!seen[f.id]) { seen[f.id] = 1; all.push(f); }
    });
    cursor = pageCursor(r);
    if (!cursor) break;
  }
  return all;
}

var MAX_PER_CLICK = 40;
async function refresh() {
  if (busy || !mcp || !db) return;
  if (!sample) { setStatus("O resumo automático precisa do Claude, que não está disponível nesta página.", "err"); return; }
  busy = true; stopRequested = false; paintRefresh(true);
  var gotLease = false;
  try {
    var lease = await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 300000 });
    if (!lease.acquired) {
      setStatus("Outra pessoa está atualizando agora. Os casos aparecem aqui assim que ficarem prontos.");
      return;
    }
    gotLease = true;
    var found = await readWholeChannel();

    var items = found.map(function (f) {
      return { id: f.id, ts: f.ts, title: f.title, kind: f.kind, team: f.team, prazo: f.prazo, replies: f.replies };
    });
    if (items.length && sig(items) !== INDEX_SIG) {
      INDEX = items.map(cleanItem).filter(Boolean); INDEX_SIG = sig(INDEX); rebuild();
      setStatus("Registrando " + INDEX.length + " casos do canal para todos…");
      await db.doc("meta/index").set({ items: INDEX, at: Date.now() });
    }

    var known = {}; CASES.forEach(function (c) { known[c.id] = c; });
    var todo = [], queued = {};
    function queue(id, ts, prazo, replies) {
      if (queued[id]) return;
      queued[id] = 1; todo.push({ id: id, ts: ts, prazo: prazo, replies: replies });
    }
    found.forEach(function (f) {
      var c = known[f.id];
      if (!c) queue(f.id, f.ts, f.prazo, f.replies);
      else if (typeof c.replies === "number" && f.replies > c.replies) queue(f.id, f.ts, f.prazo || c.prazo, f.replies);
    });
    CASES.forEach(function (c) {
      if (c.state !== "ok" && c.slack) queue(c.id, dotTs(c.slack), c.prazo, c.replies);
    });
    todo.sort(function (a, b) { return num(b.id) - num(a.id); });

    if (!todo.length) {
      await db.doc("meta/sync").set({ at: Date.now() });
      setStatus("Tudo em dia: " + CASES.length + " casos no Farol e nenhum pendente de leitura.");
      return;
    }
    var run = todo.slice(0, MAX_PER_CLICK), done = 0;
    for (var i = 0; i < run.length; i++) {
      if (stopRequested) break;
      var t = run[i], base = known[t.id];
      setStatus("Lendo " + t.id + " no Jira e no Slack (" + (i + 1) + " de " + run.length + ")…");
      var got = await Promise.all([
        call(JIRA_SRV, "getJiraIssue", { cloudId: CLOUD, issueIdOrKey: t.id, fields: ["summary", "description", "status", "labels", "assignee", "reporter", "created", "comment"], responseContentFormat: "markdown" }),
        call(SLACK_SRV, "slack_read_thread", { channel_id: CHANNEL, message_ts: t.ts, limit: 200 })
      ]);
      var jira = jiraBrief(got[0]);
      setStatus("Resumindo " + t.id + " (" + (i + 1) + " de " + run.length + "). Pode levar um minuto…");
      var raw = await sample.json(buildPrompt(t.id, t.prazo, jira, asText(got[1])), { modelTier: "default" });
      if (!raw || typeof raw !== "object") throw { code: "bad_request", message: "resposta inválida do resumo" };
      raw.prazo = t.prazo || (base && base.prazo) || "—";
      raw.jiraStatus = jira.status || "—";
      raw.slack = (base && base.slack) || undotTs(t.ts);
      raw.replies = typeof t.replies === "number" ? t.replies : (base && base.replies);
      var c = cleanCase(t.id, raw);
      if (!c) throw { code: "bad_request", message: "caso inválido" };
      await db.doc("cases/" + c.id).set(toDoc(c));
      await db.doc("meta/sync").set({ at: Date.now() });
      await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 300000 });
      done++;
    }
    var left = todo.length - done;
    setStatus((stopRequested ? "Parado. " : "Atualizado para todos. ") + done + (done === 1 ? " caso lido e resumido." : " casos lidos e resumidos.") +
      (left > 0 ? " Faltam " + left + " para ler. Clique em Atualizar para continuar de onde parou." : " Nenhum caso pendente."));
  } catch (e) {
    setStatus(errMessage(e), "err");
  } finally {
    if (gotLease) { try { await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 1000 }); } catch (e2) {} }
    busy = false; stopRequested = false; paintRefresh(false);
  }
}

/* ---------- Plano de ação ---------- */
var PLAN = "Plano de ação";
var PLAN_DOC = null;
var canWrite = true;
HINTS[PLAN] = "Sugestões para tratar cada caso e evitar que outros iguais aconteçam. São propostas para o time avaliar e decidir.";

function byNum(a, b) { return num(b.id) - num(a.id); }
function cut(n) { return function (x) { return String(x).slice(0, n); }; }
function cleanPlan(p) {
  if (!p || typeof p !== "object") return null;
  var out = {
    causa: String(p.causa || "").slice(0, 700),
    acoes: arr(p.acoes).slice(0, 8).map(cut(450)),
    prevencao: arr(p.prevencao).slice(0, 8).map(cut(450)),
    indicador: String(p.indicador || "").slice(0, 300)
  };
  return (out.causa || out.acoes.length || out.prevencao.length) ? out : null;
}
function cleanTheme(t) {
  if (!t || typeof t !== "object") return null;
  var pr = ["Alta", "Média", "Baixa"].indexOf(t.prioridade) >= 0 ? t.prioridade : "Média";
  var o = {
    tema: String(t.tema || "").slice(0, 160), problema: String(t.problema || "").slice(0, 500),
    casos: arr(t.casos).filter(function (id) { return /^JOI-\d+$/.test(id); }).slice(0, 40),
    acoes: arr(t.acoes).slice(0, 8).map(cut(450)), prevencao: arr(t.prevencao).slice(0, 8).map(cut(450)),
    responsavel: String(t.responsavel || "").slice(0, 160), prioridade: pr
  };
  return o.tema ? o : null;
}
function cleanPlanDoc(d) {
  if (!d || typeof d !== "object") return null;
  return {
    at: typeof d.at === "number" ? d.at : null, n: typeof d.n === "number" ? d.n : null,
    temas: (Array.isArray(d.temas) ? d.temas : []).map(cleanTheme).filter(Boolean).slice(0, 12)
  };
}
function ticketLink(id) {
  return '<a href="' + JIRA + esc(id) + '" target="_blank" rel="noopener">' + esc(id) + "</a>";
}
function planInline(pl) {
  var h = '<div class="plan-inline"><h3>Plano de ação sugerido</h3>';
  if (pl.causa) h += "<p><strong>Causa provável:</strong> " + esc(pl.causa) + "</p>";
  if (pl.acoes.length) h += "<h4>O que fazer</h4>" + listHtml(pl.acoes);
  if (pl.prevencao.length) h += "<h4>Como evitar que se repita</h4>" + listHtml(pl.prevencao);
  if (pl.indicador) h += '<p class="note">Como acompanhar: ' + esc(pl.indicador) + "</p>";
  return h + "</div>";
}
function priClass(p) { return p === "Alta" ? "alta" : p === "Baixa" ? "baixa" : "media"; }

function planView(q) {
  var withPlan = CASES.filter(function (c) { return c.plano && matches(c, q); }).sort(byNum);
  var allWithPlan = CASES.filter(function (c) { return c.plano; }).length;
  var pending = CASES.filter(function (c) { return c.full && !c.plano; }).length;
  var off = busy || !sample || !db || !canWrite;
  var h = '<div class="plan-actions">' +
    '<button type="button" class="btn-solid" data-act="gen-missing"' + (off || !pending ? " disabled" : "") + ">Gerar planos pendentes (" + pending + ")</button>" +
    '<button type="button" class="btn-ghost" data-act="gen-plan"' + (off || !allWithPlan ? " disabled" : "") + ">Atualizar plano consolidado</button></div>";
  if (!canWrite) h += '<p class="note">Seu acesso é de leitura: você vê os planos, mas não gera novos.</p>';

  h += '<h2 class="plan-h">Ações para evitar que se repitam</h2>';
  if (PLAN_DOC && PLAN_DOC.temas.length) {
    var when = PLAN_DOC.at ? new Date(PLAN_DOC.at).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "";
    h += '<p class="note">' + (when ? "Gerado em " + esc(when) : "Plano consolidado") + (PLAN_DOC.n ? ", com base em " + PLAN_DOC.n + " casos lidos" : "") + ".</p>";
    PLAN_DOC.temas.forEach(function (t) {
      h += '<article class="plan-card"><div class="plan-top"><h3>' + esc(t.tema) + '</h3><span class="chip ' + priClass(t.prioridade) + '">Prioridade ' + esc(t.prioridade) + "</span></div>";
      if (t.problema) h += '<p class="plan-sub">' + esc(t.problema) + "</p>";
      if (t.casos.length) h += '<p class="plan-tickets">Tickets: ' + t.casos.map(ticketLink).join(", ") + "</p>";
      if (t.acoes.length) h += "<h4>O que fazer</h4>" + listHtml(t.acoes);
      if (t.prevencao.length) h += "<h4>Como evitar que se repita</h4>" + listHtml(t.prevencao);
      if (t.responsavel) h += '<p class="plan-resp">Responsável sugerido: ' + esc(t.responsavel) + "</p>";
      h += "</article>";
    });
  } else {
    h += '<p class="empty">Ainda não há plano consolidado. Clique em “Atualizar plano consolidado” para agrupar os casos em temas.</p>';
  }

  h += '<h2 class="plan-h">Plano por caso</h2>';
  if (!withPlan.length) h += '<p class="empty">Nenhum plano encontrado para esta busca.</p>';
  withPlan.forEach(function (c) {
    h += '<article class="plan-card"><div class="plan-top"><h3>' + ticketLink(c.id) + " · " + esc(c.title) + '</h3><span class="chip ' + c.state + '">' + esc(c.stateLabel) + "</span></div>";
    h += '<p class="plan-sub">' + esc(c.team) + (c.prazo && c.prazo !== "—" ? " · prazo " + esc(c.prazo) : "") + "</p>";
    var pl = c.plano;
    if (pl.causa) h += "<p><strong>Causa provável:</strong> " + esc(pl.causa) + "</p>";
    if (pl.acoes.length) h += "<h4>O que fazer</h4>" + listHtml(pl.acoes);
    if (pl.prevencao.length) h += "<h4>Como evitar que se repita</h4>" + listHtml(pl.prevencao);
    if (pl.indicador) h += '<p class="note">Como acompanhar: ' + esc(pl.indicador) + "</p>";
    h += '<div class="links"><button type="button" class="link-btn" data-goto="' + esc(c.id) + '">Abrir o caso completo</button></div></article>';
  });
  return h;
}

function planPrompt(c) {
  var r = c.response;
  var data = {
    id: c.id, time: c.team, titulo: c.title, situacao: c.stateLabel, prazo: c.prazo,
    ticket: clip((c.ticket || []).join(" "), 900),
    passoAPasso: (c.steps || []).slice(-10).map(function (s) { return s.when + ": " + clip(s.text, 170); }),
    resposta: r ? { resumo: clip(r.resumo, 600), gaps: r.gaps, riscos: r.riscos, desfecho: clip(r.desfecho || "", 240), envio: clip(r.envio || "", 200) } : null
  };
  return "Você ajuda a equipe do OID (Operational Intelligence Desk) a tratar casos jurídicos e a evitar que casos iguais aconteçam de novo. " +
    "Responda SOMENTE com um objeto JSON válido, sem texto antes ou depois e sem crases.\n\n" +
    "REGRAS\n" +
    "- Português do Brasil, texto simples, frases curtas e práticas, específicas para este caso.\n" +
    "- acoes: 3 a 5 ações para tratar o caso. Cada uma diz o que fazer, cita o ticket (" + c.id + ") e termina com \"Responsável sugerido: X\" (OOS, Simba, LW Suits, Legal, Strategic Defense, Qualidade, Produto, Engenharia ou Operação).\n" +
    "- prevencao: 3 a 4 medidas para evitar que outros casos iguais aconteçam (processo, checklist, treinamento, alerta, macro, ferramenta), cada uma com \"Responsável sugerido: X\".\n" +
    "- causa: a causa provável em 1 ou 2 frases, com base só nos dados abaixo. Se não houve falha, diga isso e proponha acompanhamento e boas práticas.\n" +
    "- indicador: uma frase dizendo como acompanhar se a prevenção funciona.\n" +
    "- Não invente fatos além dos dados. Não inclua CPF, CNPJ de pessoa física nem número de conta.\n\n" +
    "FORMATO\n{\"causa\":\"\",\"acoes\":[\"\"],\"prevencao\":[\"\"],\"indicador\":\"\"}\n\n" +
    "CASO (JSON):\n" + clip(JSON.stringify(data), 14000);
}

async function runJob(worker) {
  if (busy || !sample || !db || !canWrite) return;
  busy = true; stopRequested = false; paintRefresh(true);
  var got = false;
  try {
    var lease = await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 300000 });
    if (!lease.acquired) {
      setStatus("Outra pessoa está atualizando agora. Os resultados aparecem aqui assim que ficarem prontos.");
      return;
    }
    got = true;
    await worker();
  } catch (e) {
    setStatus(errMessage(e), "err");
  } finally {
    if (got) { try { await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 1000 }); } catch (e2) {} }
    busy = false; stopRequested = false; paintRefresh(false);
  }
}
function genMissing() {
  return runJob(async function () {
    var list = CASES.filter(function (c) { return c.full && !c.plano; }).sort(byNum).slice(0, 30), done = 0;
    for (var i = 0; i < list.length; i++) {
      if (stopRequested) break;
      var c = list[i];
      setStatus("Gerando o plano de ação de " + c.id + " (" + (i + 1) + " de " + list.length + ")…");
      var raw = await sample.json(planPrompt(c), { modelTier: "default" });
      var pl = cleanPlan(raw && raw.plano ? raw.plano : raw);
      if (!pl) throw { code: "bad_request", message: "plano inválido" };
      var nc = toDoc(c); nc.plano = pl;
      await db.doc("cases/" + c.id).set(nc);
      await db.doc("meta/lock").acquire({ holder: tabId, ttlMs: 300000 });
      done++;
    }
    var left = CASES.filter(function (c) { return c.full && !c.plano; }).length;
    setStatus((stopRequested ? "Parado. " : "Pronto para todos. ") + done + (done === 1 ? " plano gerado." : " planos gerados.") +
      (left > 0 ? " Faltam " + left + ". Clique de novo para continuar." : ""));
  });
}
function genConsolidated() {
  return runJob(async function () {
    var src = CASES.filter(function (c) { return c.plano || c.response; }).sort(byNum).map(function (c) {
      var r = c.response, p = c.plano;
      return {
        id: c.id, time: c.team, titulo: clip(c.title, 120),
        gaps: r ? (r.gaps || []).slice(0, 3).map(function (g) { return clip(g, 140); }) : [],
        riscos: r ? (r.riscos || []).slice(0, 2).map(function (g) { return clip(g, 120); }) : [],
        causa: p ? clip(p.causa, 220) : "",
        prevencao: p ? p.prevencao.slice(0, 2).map(function (g) { return clip(g, 160); }) : []
      };
    });
    if (!src.length) throw { code: "bad_request", message: "sem casos" };
    setStatus("Agrupando " + src.length + " casos em temas e montando o plano consolidado. Pode levar alguns minutos…");
    var prompt = "Você ajuda a equipe do OID (Operational Intelligence Desk) a evitar que casos jurídicos se repitam. " +
      "Com base nos casos abaixo, agrupe os problemas em no máximo 8 temas recorrentes e proponha um plano de ação por tema. " +
      "Responda SOMENTE com um objeto JSON válido, sem texto antes ou depois e sem crases.\n\n" +
      "REGRAS\n- Português do Brasil, texto simples e prático.\n" +
      "- tema: nome curto. problema: 1 ou 2 frases sobre o que se repete.\n" +
      "- casos: códigos JOI dos tickets do tema, usando só códigos que aparecem nos dados. Cite vários casos por tema sempre que houver.\n" +
      "- acoes: 2 a 4 ações para tratar o tema. prevencao: 2 a 4 medidas para evitar novos casos. Cada item termina com \"Responsável sugerido: X\".\n" +
      "- responsavel: áreas envolvidas no tema. prioridade: \"Alta\", \"Média\" ou \"Baixa\", conforme o risco (multa, sanção, exposição de dados, repetição). Ordene do mais prioritário ao menos.\n" +
      "- Não invente fatos além dos dados. Sem CPF, CNPJ de pessoa física ou número de conta.\n\n" +
      "FORMATO\n{\"temas\":[{\"tema\":\"\",\"problema\":\"\",\"casos\":[\"JOI-0\"],\"acoes\":[\"\"],\"prevencao\":[\"\"],\"responsavel\":\"\",\"prioridade\":\"Alta\"}]}\n\n" +
      "CASOS (JSON):\n" + clip(JSON.stringify(src), 90000);
    var raw = await sample.json(prompt, { modelTier: "default" });
    var doc = cleanPlanDoc({ at: Date.now(), n: src.length, temas: raw && raw.temas });
    if (!doc || !doc.temas.length) throw { code: "bad_request", message: "plano consolidado inválido" };
    var ids = {}; CASES.forEach(function (c) { ids[c.id] = 1; });
    doc.temas.forEach(function (t) { t.casos = t.casos.filter(function (id) { return ids[id]; }); });
    await db.doc("meta/plan").set(doc);
    setStatus("Plano consolidado atualizado para todos, com " + doc.temas.length + " temas.");
  });
}
document.getElementById("plan-btn").addEventListener("click", function () {
  active = PLAN; render();
  var t = document.getElementById("tabs");
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  t.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
});

/* ---------- Assistente: responde sobre os casos da página ---------- */
var ASK_IDEAS = [
  "Quais casos estão em andamento?",
  "Qual caso tem o prazo mais próximo?",
  "Resuma o último caso finalizado",
  "Quais gaps mais se repetem?",
  "Quais casos são do Simba?",
  "O que foi respondido no JOI-397?",
  "Quais ações evitam novos casos parecidos?"
];
var chat = { open: false, busy: false, history: [] };
var MASCOT_AVATAR = '<svg class="mascot" viewBox="0 0 64 64" aria-hidden="true"><use href="#mascot"/></svg>';

function chatDigest() {
  var read = CASES.filter(function (c) { return c.full; }).sort(function (a, b) { return num(b.id) - num(a.id); });
  var lidos = read.map(function (c, i) {
    var r = c.response;
    if (i >= 10) {
      return {
        id: c.id, time: c.team, titulo: clip(c.title, 120), prazo: c.prazo, situacao: c.stateLabel,
        resumo: r ? clip(r.resumo, 260) : clip((c.ticket || []).join(" "), 260),
        gaps: r ? (r.gaps || []).slice(0, 2).map(function (g) { return clip(g, 110); }) : [],
        envio: r ? clip(r.envio || "", 120) : ""
      };
    }
    var o = {
      id: c.id, time: c.team, titulo: c.title, prazo: c.prazo, statusJira: c.jiraStatus,
      situacao: c.stateLabel, responsavel: c.owner,
      ticket: clip((c.ticket || []).join(" "), 800),
      passoAPasso: (c.steps || []).slice(-14).map(function (s) { return s.when + ": " + clip(s.text, 180); }),
      resposta: null
    };
    if (c.plano) o.plano = { causa: clip(c.plano.causa, 300), acoes: c.plano.acoes.slice(0, 4).map(function (x) { return clip(x, 200); }), prevencao: c.plano.prevencao.slice(0, 3).map(function (x) { return clip(x, 200); }) };
    if (r) {
      o.resposta = {
        titulo: clip(r.title, 200), resumo: clip(r.resumo, 600),
        gaps: (r.gaps || []).map(function (g) { return clip(g, 160); }),
        riscos: (r.riscos || []).map(function (g) { return clip(g, 160); }),
        envio: clip(r.envio || "", 200), desfecho: clip(r.desfecho || "", 240), por: r.by
      };
    }
    return o;
  });
  var sem = CASES.filter(function (c) { return !c.full; }).sort(function (a, b) { return num(b.id) - num(a.id); }).map(function (c) {
    return { id: c.id, titulo: clip(c.title, 110), prazo: c.prazo, tipo: String(c.owner).split(" · ")[0] };
  });
  return clip(JSON.stringify({ casosLidos: lidos, casosSemLeitura: sem, planoConsolidado: PLAN_DOC ? PLAN_DOC.temas.map(function (t) { return { tema: t.tema, prioridade: t.prioridade, casos: t.casos, acoes: t.acoes.map(function (x) { return clip(x, 200); }), prevencao: t.prevencao.map(function (x) { return clip(x, 200); }) }; }) : [] }), 110000);
}
function chatContext() {
  return "Você é o Inspetor Roxinho, assistente do Farol OID, uma página que reúne os casos do canal #operational-intelligence-desk. " +
    "Responda apenas com base nos casos abaixo. Se a informação não estiver neles, diga que não consta. " +
    "Escreva em português do Brasil, em texto simples: sem markdown, sem asteriscos e sem títulos. " +
    "Seja curto (até umas 6 linhas) e cite sempre os códigos JOI dos casos. Para listas use linhas começando com hífen. " +
    "Não invente datas nem números. Hoje é " + new Date().toLocaleDateString("pt-BR") + "; use isso para falar de prazos. " +
    "Em casosSemLeitura há só título e prazo: se a pergunta pedir detalhes deles, diga que ainda não foram lidos e sugira clicar em Atualizar. "+
    "planoConsolidado traz os temas do plano de ação para evitar novos casos, e o campo plano de cada caso traz causa, ações e prevenção sugeridas; ao falar de plano, cite o ticket. "+
    "Os campos de casosLidos: time (OOS, Simba ou LW Suits), situacao (andamento ou finalizado), resposta (encerramento do caso, com gaps e riscos mapeados).\n\n" +
    "CASOS (JSON):\n" + chatDigest();
}
function chatScroll() { var l = document.getElementById("chat-log"); l.scrollTop = l.scrollHeight; }
function addMsg(role, text) {
  var m = document.createElement("div");
  m.className = "msg " + role;
  var t = document.createElement("div");
  t.className = "txt"; t.textContent = text;
  m.appendChild(t);
  var log = document.getElementById("chat-log");
  if (role === "user") { log.appendChild(m); }
  else {
    var row = document.createElement("div");
    row.className = "row";
    row.insertAdjacentHTML("afterbegin", MASCOT_AVATAR);
    row.appendChild(m);
    log.appendChild(row);
  }
  chatScroll();
  return m;
}
function cleanAnswer(s) { return String(s || "").replace(/\*\*/g, "").replace(/^#+\s*/gm, ""); }
function goToCase(id) {
  var c = null;
  CASES.forEach(function (x) { if (x.id === id) c = x; });
  if (!c) return;
  active = c.team; open[c.id] = true;
  document.getElementById("q").value = "";
  render();
  var el = document.querySelector('.case[data-id="' + c.id + '"]');
  if (el) {
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "center" });
  }
  if (window.innerWidth <= 640) toggleChat(false);
}
function addCaseLinks(m, text) {
  var ids = [], seen = {};
  (String(text).match(/JOI-\d+/g) || []).forEach(function (id) {
    var ok = CASES.some(function (c) { return c.id === id; });
    if (ok && !seen[id] && ids.length < 4) { seen[id] = 1; ids.push(id); }
  });
  if (!ids.length) return;
  var box = document.createElement("div");
  box.className = "msg-links";
  ids.forEach(function (id) {
    var b = document.createElement("button");
    b.type = "button"; b.textContent = "Abrir " + id;
    b.addEventListener("click", function () { goToCase(id); });
    box.appendChild(b);
  });
  m.appendChild(box);
}
function chatErr(e) {
  switch (e && e.code) {
    case "not_granted":
      return "Para responder, o assistente usa o Claude da sua conta e precisa da sua permissão. Envie a pergunta de novo e permita quando o claude.ai perguntar.";
    case "rate_limited":
      return "Muitas perguntas seguidas. Aguarde um instante e tente de novo.";
    default:
      return "Não consegui responder agora. Tente de novo em instantes.";
  }
}
function setChatBusy(b) {
  chat.busy = b;
  document.getElementById("chat-input").disabled = b;
  document.getElementById("chat-send").disabled = b;
  Array.prototype.forEach.call(document.querySelectorAll(".sugg-btn, #chat-more"), function (x) { x.disabled = b; });
}
async function askChat(q) {
  q = String(q || "").trim();
  if (!q || chat.busy || !sample) return;
  setChatBusy(true);
  document.getElementById("chat-sugg").hidden = false;
  document.getElementById("chat-input").value = "";
  addMsg("user", q);
  var bot = addMsg("bot", "Investigando…");
  var txt = bot.firstChild;
  var ctx = chatContext(), input = [], first = true;
  chat.history.slice(-6).forEach(function (t) {
    input.push({ role: "user", content: (first ? ctx + "\n\nPERGUNTA: " : "") + t.q });
    input.push({ role: "assistant", content: t.a });
    first = false;
  });
  input.push({ role: "user", content: (first ? ctx + "\n\nPERGUNTA: " : "") + q });
  try {
    var res = await sample(input, {
      modelTier: "default",
      onText: function (e) { txt.textContent = cleanAnswer(e.text); chatScroll(); }
    });
    var text = cleanAnswer(res && res.text).trim() || "Não consegui montar uma resposta. Tente reformular a pergunta.";
    txt.textContent = text;
    chat.history.push({ q: q, a: text });
    addCaseLinks(bot, text);
  } catch (e) {
    txt.textContent = chatErr(e);
    bot.classList.add("err");
  } finally {
    setChatBusy(false);
    chatScroll();
    if (chat.open) document.getElementById("chat-input").focus();
  }
}
function toggleChat(show) {
  chat.open = typeof show === "boolean" ? show : !chat.open;
  document.getElementById("chat").hidden = !chat.open;
  var fab = document.getElementById("chat-fab");
  fab.setAttribute("aria-expanded", String(chat.open));
  if (chat.open) {
    chatScroll();
    document.getElementById("chat-input").focus();
  } else {
    fab.focus();
  }
}
function addSuggestions(text) {
  var m = addMsg("bot", text);
  m.classList.add("wide");
  var list = document.createElement("div");
  list.className = "sugg-list";
  ASK_IDEAS.forEach(function (q) {
    var b = document.createElement("button");
    b.type = "button"; b.className = "sugg-btn"; b.textContent = q;
    b.disabled = chat.busy;
    b.addEventListener("click", function () { askChat(q); });
    list.appendChild(b);
  });
  m.appendChild(list);
  chatScroll();
}
function initAssistant() {
  if (!sample) return;
  var log = document.getElementById("chat-log");
  if (!log.childNodes.length) addSuggestions("Elementar! Sou o Inspetor Roxinho e investigo os casos que estão aqui no Farol. Escolha uma sugestão ou escreva sua pergunta.");
  document.getElementById("chat-more").addEventListener("click", function () {
    addSuggestions("Aqui vão algumas sugestões:");
  });
  document.getElementById("chat-fab").addEventListener("click", function () { toggleChat(); });
  document.getElementById("chat-close").addEventListener("click", function () { toggleChat(false); });
  document.getElementById("chat-send").addEventListener("click", function () { askChat(document.getElementById("chat-input").value); });
  document.getElementById("chat-input").addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); askChat(this.value); }
  });
  document.getElementById("chat").addEventListener("keydown", function (e) {
    if (e.key === "Escape") toggleChat(false);
  });
  document.getElementById("assistant").hidden = false;
}

(function initRefresh() {
  updateSnap(); render();
  var btn = document.getElementById("refresh");
  btn.insertAdjacentHTML("afterbegin", REFRESH_ICON);
  btn.addEventListener("click", refresh);
  document.getElementById("stop").addEventListener("click", function () {
    stopRequested = true;
    setStatus("Parando depois do caso que está sendo lido…");
  });
  var cl = window.claude;
  if (!cl || typeof cl.use !== "function") {
    disableRefresh();
    setStatus("Para ver os casos compartilhados e atualizar, abra a página no claude.ai.");
    return;
  }
  Promise.all([
    cl.use("db").catch(function () { return null; }),
    cl.use("mcp").catch(function () { return null; }),
    cl.use("sample").catch(function () { return null; }),
    cl.use("user").catch(function () { return null; })
  ]).then(function (r) {
    db = r[0]; mcp = r[1]; sample = r[2];
    initAssistant();
    var user = r[3];
    if (!db) {
      disableRefresh();
      setStatus("Não foi possível abrir os casos compartilhados. Entre no claude.ai e recarregue. Mostrando os casos que vieram com a página.");
      return;
    }
    subscribe();
    if (!mcp) {
      disableRefresh();
      setStatus("A atualização automática não está disponível aqui. Abra a página no claude.ai com Slack e Jira conectados.");
      return;
    }
    if (user && typeof user.can === "function") {
      Promise.resolve(user.can("data.write")).then(function (ok) {
        if (ok === false) {
          canWrite = false;
          disableRefresh();
          setStatus("Seu acesso a esta página é de leitura: você vê todos os casos, mas não atualiza. Peça o nível de Colaborador no compartilhamento.");
        }
      }).catch(function () {});
    }
  });
})();
