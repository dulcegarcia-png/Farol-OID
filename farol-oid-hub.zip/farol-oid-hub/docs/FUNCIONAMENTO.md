# Como a ferramenta funciona

## 1. Visão geral

O Farol OID reúne em um só lugar os casos que entram no canal **#operational-intelligence-desk**. Cada caso tem:

1. o **link do ticket** no Jira (e da thread no Slack);
2. um **resumo do que o analista registrou** no ticket;
3. o **passo a passo** da thread, em linha do tempo;
4. a **resposta enviada** (o texto de encerramento “OID Finalizado”, com gaps e riscos mapeados);
5. um **plano de ação** sugerido, com causa provável, ações, prevenção e indicador.

Os casos ficam distribuídos em três times: **OOS**, **Simba** e **LW Suits**.

## 2. Tela por tela

### Faixa do topo
- **Nome e desenho:** “Farol OID”, com um farol desenhado.
- **Atualizar:** lê o Slack e o Jira e grava os casos para todos (item 3).
- **Parar:** aparece só enquanto uma leitura está em andamento. Encerra depois do caso que está sendo lido.
- **Plano de ação:** abre a tela do plano (item 5).
- **Botão de tema (sol e lua):** alterna entre tela clara e escura. Na primeira visita segue o tema do aparelho. A escolha fica salva no navegador.
- **Linha de resumo:** mostra “Atualizado em dd/mm/aaaa hh:mm” (da última atualização feita por qualquer pessoa) e quantos casos existem, quantos têm resumo e quantos há por time.

### Busca e filtro
- **Campo de busca:** procura por código do JOI, time, título, responsável, situação, texto do ticket, passo a passo, resposta e plano. Aceita datas em `19/11`, `19/11/2026`, `2026-11-19` e `19-11`, que casam com prazo, data de abertura, data dos passos e data de finalização.
- **Mês de abertura:** lista os meses que existem nos casos, com a quantidade em cada um. Filtra todas as abas e o “Plano por caso”. A data de abertura vem do horário da mensagem do caso no Slack.

### Abas
- **OOS, Simba, LW Suits:** lista de casos do time, do mais novo para o mais antigo. Cada caso mostra título, prazo, data de abertura, responsável e situação (Finalizado, Em andamento, Devolvido, Aguardando leitura). Ao clicar abre:
  - links para o ticket e para a thread;
  - **O que o analista registrou no ticket** (resumo);
  - **Passo a passo** (linha do tempo com data e hora);
  - **Plano de ação sugerido** (quando existe).
- **Resposta enviada:** o texto de encerramento de cada caso finalizado (título, resumo, gaps, riscos, boas práticas, desfecho e envio), com filtro por time e links para o ticket e a thread.
- **Plano de ação:** item 5.

### Casos “Aguardando leitura”
São casos que o Atualizar já registrou (com link, título, tipo e prazo), mas cujo ticket e thread ainda não foram lidos. O time mostrado é provisório e é confirmado na leitura.

## 3. O botão Atualizar, passo a passo

1. **Trava:** tenta pegar a trava `meta/lock` (válida por 5 minutos e renovada a cada caso). Se outra pessoa já estiver atualizando, avisa e para.
2. **Leitura do canal:** lê o canal inteiro, desde a abertura, de 100 em 100 mensagens (até 40 páginas). Em cada mensagem procura o link `browse/JOI-nnn`.
   - Ignora “novo alinhamento” (@focais-agora-judorders), que não são casos do OID.
   - Guarda o título, o tipo, o time provável, o prazo e a quantidade de respostas da thread.
3. **Registro de todos os casos:** grava a lista no documento `meta/index`, só se algo mudou. A partir daí todos veem todos os casos, ainda sem resumo.
4. **Fila de leitura:** entram na fila (a) casos sem resumo, (b) casos já lidos cuja thread ganhou respostas novas e (c) casos em andamento. A fila vai do mais novo para o mais antigo, com no máximo **40 casos por clique**.
5. **Para cada caso da fila:**
   - lê o ticket no Jira (resumo, descrição, status, labels, responsável, autor, data e comentários);
   - lê a thread do Slack (até 200 mensagens);
   - pede ao Claude um resumo estruturado (prompt 1 em `PROMPTS.md`), que já inclui o plano de ação;
   - valida e limpa o resultado (`cleanCase`) e grava em `cases/JOI-nnn`;
   - atualiza `meta/sync` e renova a trava.
6. **Fim:** libera a trava e mostra quantos casos foram lidos e quantos faltam. Um novo clique continua de onde parou.

Se algo falhar, a faixa de aviso explica o que fazer e os casos já gravados permanecem. Os erros mais comuns: conector não conectado, conexão expirada, permissão negada, limite de chamadas e serviço sem resposta.

### Regras de classificação por time
- **OOS (padrão):** casos direcionados ao grupo @oos-oid (sanção aplicada, reiteração, ofício fora do padrão).
- **LW Suits:** pedidos de dossiê (@lawsuits-oid), fraude SISBAJUD e casos conduzidos pelo time de Lawsuits Defense (por exemplo Lívia Zaroni e Íris Almeida).
- **Simba:** casos que o time de Simba (por exemplo Felipe Rocha) assume ou trata na thread.

Antes da leitura o time vem só do tipo da mensagem. Depois da leitura, o Claude decide pela thread.

## 4. Planos de ação

- **Por caso:** cada caso lido traz `plano` com causa provável, 3 a 5 ações (citando o ticket e um responsável sugerido), 3 a 4 medidas de prevenção e um indicador de acompanhamento.
- **Gerar planos pendentes:** gera o plano dos casos já lidos que ainda não têm, sem reler Jira nem Slack (até 30 por clique).
- **Atualizar plano consolidado:** agrupa os casos em até 8 temas recorrentes, cada um com problema, tickets (com link), ações, prevenção, responsável sugerido e prioridade (Alta, Média ou Baixa). Grava em `meta/plan`.
- Os planos são **sugestões** para o time avaliar. Os responsáveis citados são propostas, não atribuições.

## 5. Assistente “Inspetor Roxinho”

- Botão no canto inferior direito, com o mascote (um detetive com chapéu e lupa nas cores do Nubank).
- Responde com base nos casos que estão na página: os 10 mais novos lidos entram em detalhe, os demais lidos em resumo, e os não lidos só com título e prazo. O plano consolidado também entra.
- Perguntas sugeridas em lista vertical (as 7 perguntas ficam em `ASK_IDEAS`). O link “Ver sugestões de perguntas” traz a lista de volta depois da primeira pergunta.
- Quando a resposta cita um caso aparece o botão “Abrir JOI-nnn”, que leva à aba certa e abre o caso.
- A conversa não é salva nem compartilhada.

## 6. Permissões

| Nível no compartilhamento | O que consegue fazer |
|---|---|
| Visualizador ou Comentarista | Ver todos os casos, buscar, filtrar, usar o assistente. Não grava: Atualizar e geração de planos ficam desativados e a página explica. |
| Colaborador (Contributor) | Tudo acima, mais Atualizar e geração de planos. |
| Editor e Proprietário | Tudo acima, mais publicar novas versões da página. |

Além do nível, quem atualiza precisa estar no canal privado e ter Slack e Atlassian conectados.

## 7. Comportamento em falhas

- **Banco indisponível ou sem resposta em 10 segundos:** a página mostra os 10 casos embutidos e avisa.
- **Aberta fora do claude.ai:** modo leitura, só com os casos embutidos. Atualizar e assistente ficam desativados.
- **Conector com nome diferente de “Slack” ou “Atlassian”:** o aviso informa o conector que falta.
- **Dois cliques ao mesmo tempo:** a trava impede a leitura duplicada; quem chegou depois vê o resultado em tempo real.

## 8. Segurança e privacidade

- Todo texto vindo do banco ou do Claude passa por validação de formato (`cleanCase`, `cleanItem`, `cleanPlan`, `cleanPlanDoc`) e por escape de HTML na hora de exibir.
- Links externos só são gerados a partir de IDs validados (`JOI-nnn`, ID de thread de 16 dígitos) ou, quando vêm dos dados embutidos, com `https://`.
- Os prompts pedem para não incluir CPF, CNPJ de pessoa física, número de conta ou dados bancários pessoais. Isso reduz o risco, mas não o elimina.
- O Claude recebe o texto do ticket e da thread para resumir. Isso acontece na conta de quem clica.
