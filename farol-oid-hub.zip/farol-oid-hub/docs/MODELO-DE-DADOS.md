# Modelo de dados

A ferramenta usa o banco de documentos da própria página (capability `db` do claude.ai). Cada documento tem no máximo 256 KB e o banco, no máximo 25.000 documentos. Regras de acesso: padrão (todos leem, a partir de Colaborador escrevem).

## Mapa

| Caminho | Quem escreve | Conteúdo |
|---|---|---|
| `cases/JOI-nnn` | Atualizar e Gerar planos pendentes | Um caso lido, com resumo, passos, resposta e plano. |
| `meta/index` | Atualizar | Lista de todos os casos do canal (sem resumo). |
| `meta/sync` | Atualizar | Data da última atualização. |
| `meta/lock` | Atualizar, Gerar planos pendentes e plano consolidado | Trava para uma pessoa por vez. |
| `meta/plan` | Atualizar plano consolidado | Plano consolidado em temas. |

Além do banco, a página embute no código os **10 casos iniciais** (`BASE_CASES`) e os **planos desses casos** (`BASE_PLANS`). Quando um documento de `cases/` tem o mesmo ID, ele prevalece sobre o embutido.

## `cases/JOI-nnn`

```json
{
  "id": "JOI-395",
  "team": "OOS",
  "title": "CRIME DE DESOBEDIÊNCIA",
  "prazo": "18/11/2026",
  "jiraStatus": "Em análise",
  "state": "ok",
  "stateLabel": "Finalizado em 19/11",
  "owner": "Aberto por Sidiney Nascimento",
  "slack": "1794602433923569",
  "full": true,
  "replies": 6,
  "ticket": ["Parágrafo resumindo o ticket", "..."],
  "steps": [{ "when": "13/11 · 17:49", "text": "Quem fez o quê." }],
  "response": {
    "title": "Título do encerramento",
    "resumo": "Resumo do caso",
    "gaps": ["..."],
    "riscos": ["..."],
    "boas": ["..."],
    "desfecho": "Texto opcional",
    "envio": "Se, quando e por quem a resposta foi enviada (opcional)",
    "by": "Mariana Guareschi, 19/11/2026"
  },
  "plano": {
    "causa": "Causa provável em 1 ou 2 frases",
    "acoes": ["... Responsável sugerido: OOS."],
    "prevencao": ["... Responsável sugerido: Qualidade."],
    "indicador": "Como acompanhar"
  }
}
```

Campos e regras:
- `team`: `OOS`, `Simba` ou `LW Suits` (outro valor vira `OOS`).
- `state`: `ok` (finalizado ou devolvido), `wip` (em andamento) ou `todo` (aguardando leitura). Outro valor vira `wip`.
- `slack`: ID da mensagem da thread sem o ponto (16 dígitos). Dele saem o link da thread e a **data de abertura** (os 10 primeiros dígitos são os segundos desde 1970).
- `replies`: respostas da thread no momento da leitura. Se a thread crescer, o caso volta para a fila.
- `response`: `null` enquanto não houver mensagem de encerramento. `boas`, `desfecho` e `envio` são opcionais.
- `plano`: `null` até ser gerado.
- A chave de busca do Jira é o próprio ID do documento.

## `meta/index`

```json
{
  "at": 1795525733216,
  "items": [
    {
      "id": "JOI-397",
      "ts": "1794950427.203989",
      "title": "Intimação de Descumprimento - Quebra de Sigilo Bancário",
      "kind": "Reiteração",
      "team": "OOS",
      "prazo": "27/11/2026",
      "replies": 6
    }
  ]
}
```

- `ts`: horário da mensagem no Slack (com ponto). É o ponto de partida para ler a thread.
- `kind`: `Reiteração`, `Sanção aplicada`, `Ofício fora do padrão`, `Pedido de dossiê`, `Fraude SISBAJUD` ou `Caso OID`.
- O documento só é regravado quando muda algo: a assinatura considera id, respostas, título, tipo e time.
- Um caso do índice sem documento em `cases/` aparece na tela como “Aguardando leitura”.

## `meta/sync`

```json
{ "at": 1795526086925 }
```
`at` é o horário (milissegundos desde 1970) da última atualização.

## `meta/lock`

Documento de lease do banco (`acquire`). Guarda de quem é a trava e quando expira. Dura 5 minutos e é renovada a cada caso. No fim, a página a encurta para 1 segundo para liberar logo. Não é uma barreira de segurança: só coordena páginas que usam o mesmo mecanismo.

## `meta/plan`

```json
{
  "at": 1795560000000,
  "n": 10,
  "temas": [
    {
      "tema": "Reiterações respondidas sem rever o histórico",
      "problema": "O que se repete, em 1 ou 2 frases",
      "casos": ["JOI-395", "JOI-390"],
      "acoes": ["... Responsável sugerido: OOS."],
      "prevencao": ["... Responsável sugerido: Produto e Engenharia."],
      "responsavel": "OOS, Strategic Defense",
      "prioridade": "Alta"
    }
  ]
}
```

- `n`: quantos casos serviram de base.
- `prioridade`: `Alta`, `Média` ou `Baixa`.
- Os códigos em `casos` são filtrados para só ficarem os que existem na página.

## Como a página protege a leitura

Todo documento lido do banco passa por um limpador antes de ir para a tela:
`cleanCase` (casos), `cleanItem` (índice), `cleanPlan` e `cleanPlanDoc` (planos). Eles forçam tipos, cortam tamanhos, descartam IDs inválidos e trocam valores fora da lista permitida pelo valor padrão.
