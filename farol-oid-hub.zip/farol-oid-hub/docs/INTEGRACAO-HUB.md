# Colocando no HUB do time

A ferramenta usa recursos que só existem dentro do claude.ai (banco compartilhado, conectores, Claude e identidade do usuário). O que funciona no HUB depende de como ela é colocada lá.

## Comparação das opções

| | A. Link ou iframe do artifact | B. Arquivo HTML hospedado no HUB | C. Reescrita com backend próprio |
|---|---|---|---|
| Esforço | Nenhum | Baixo | Alto |
| Ver os casos | Todos os casos, em tempo real | Só os 10 casos embutidos | Todos |
| Busca, filtro por mês, plano por caso, tema claro e escuro | Sim | Sim (nos 10 casos) | Sim |
| Botão Atualizar | Sim | Não | Sim |
| Assistente | Sim | Não | Sim |
| Gerar planos e plano consolidado | Sim | Não | Sim |
| Dados compartilhados entre usuários | Sim | Não | Sim |
| Exige login no claude.ai | Sim | Não | Não |

## Opção A. Link ou iframe do artifact (recomendada)

1. Compartilhe o artifact com o time: botão Compartilhar, nível **Colaborador (Contributor)** para quem deve atualizar e Visualizador para quem só consulta.
2. No HUB, adicione o link `https://claude.ai/artifact/KTNyW3rftFRejgVRhzoHcR`.
3. Se o HUB aceitar incorporar páginas (iframe), teste primeiro: o claude.ai pode impedir a incorporação por cabeçalhos de segurança. Se não abrir, use o link em nova aba.
4. Combine com o time quem faz a primeira leitura longa (cerca de um minuto por caso, no Claude de quem clica).

O que a pessoa precisa para atualizar está no `README.md`.

## Opção B. Hospedar o arquivo `farol-oid.html`

Copie o arquivo para o HUB e sirva como página estática.

- Sem o `window.claude` a página entra em **modo leitura**: mostra os 10 casos embutidos, com busca, filtro por mês, abas, plano por caso e tema claro e escuro. Atualizar, assistente e geração de planos ficam desativados, com um aviso na tela.
- O HUB precisa permitir carregar fontes do Google Fonts (ou aceitar as fontes de sistema).
- **Atenção:** o arquivo contém resumos de casos reais. Aplique no HUB o mesmo controle de acesso que o time usa para esse tipo de informação.
- O conteúdo ficará **parado** na data do pacote. Para atualizar, é preciso gerar um novo arquivo a partir do artifact.

## Opção C. Reescrever para rodar fora do claude.ai

Para o HUB oferecer todas as funções com infraestrutura própria, troque estes pontos do código. Toda a interface, a busca, os filtros, a validação e o desenho permanecem.

| Ponto no código | Hoje | Troca sugerida |
|---|---|---|
| `call(server, tool, input)` | `mcp.callTool` nos conectores Slack e Atlassian | Chamadas ao seu backend. Veja os endpoints abaixo. |
| `sample.json(...)` e `sample(...)` | Claude da conta de quem clica | Backend que chama a API de um modelo (por exemplo a API da Anthropic), com chave guardada no servidor. |
| `db.collection(...).onSnapshot`, `db.doc(...).set/acquire` | Banco compartilhado do artifact | Seu banco (SQL, Firestore ou outro) com API; para tempo real, WebSocket ou atualização periódica. |
| `user.can("data.write")` | Nível de compartilhamento do artifact | Permissões do HUB (login único). |
| `claude.use(...)` em `initRefresh()` | Obtém as capabilities | Troque por seus clientes de API. |

### Endpoints sugeridos para o backend

| Endpoint | O que faz | Observação |
|---|---|---|
| `GET /canal` | Lista as mensagens do canal, paginadas | Slack Web API `conversations.history`. Canal privado exige o escopo `groups:history` e o app no canal. |
| `GET /thread/:ts` | Lê as respostas de uma thread | Slack `conversations.replies`. |
| `GET /ticket/:key` | Lê o ticket | Jira Cloud REST v3 `GET /rest/api/3/issue/{key}`. O texto vem em ADF (formato do Jira): converta para texto antes de enviar ao modelo, porque hoje a página recebe markdown. |
| `POST /resumir` | Recebe ticket e thread, devolve o JSON do caso | Usa o prompt 1 de `PROMPTS.md`. Valide com o mesmo esquema de `cleanCase`. |
| `POST /plano` e `POST /plano-consolidado` | Prompts 2 e 3 | Idem. |
| `POST /assistente` | Prompt 4 | Idem. |
| `GET/PUT /casos`, `/indice`, `/sync`, `/plano` | Leitura e gravação dos documentos descritos em `MODELO-DE-DADOS.md` | A trava (`meta/lock`) pode virar uma trava de banco com validade. |

Pontos de atenção na reescrita:
- `parseChannel()` depende do texto formatado pelo conector (`=== Message from`, `Message TS:` etc.). Com a API do Slack, leia os campos diretamente (`ts`, `text`, `reply_count`).
- Mantenha os limpadores (`cleanCase` e semelhantes) e o escape de HTML, pois tratam dados de várias pessoas e do modelo.
- Os planos e o resumo vêm de um modelo de linguagem. Mantenha o aviso de que são sugestões.

## Dados e privacidade

- O conteúdo do banco compartilhado **não está** neste pacote. Para migrar, peça uma exportação dos documentos `cases/*`, `meta/index`, `meta/sync` e `meta/plan`. Ela pode ser feita no claude.ai, no próprio artifact, por quem for o proprietário.
- Os casos têm ofícios judiciais, sigilo bancário e dados de clientes. Defina com Privacidade e Legal quem pode ver o quê no HUB.
- Se o HUB tiver mais público do que o canal #operational-intelligence-desk, considere remover os casos embutidos (`CASES`, `BASE_CASES` e `BASE_PLANS` em `farol-oid.html`) antes de publicar.
- O botão Atualizar envia texto de ticket e de thread ao Claude. Confirme que isso está de acordo com a política da área.

## Checklist de entrega ao HUB

- [ ] Definir a opção (A, B ou C).
- [ ] Compartilhar o artifact com o time e com o nível certo para cada pessoa.
- [ ] Confirmar que quem vai atualizar está no canal e tem Slack e Atlassian conectados.
- [ ] Combinar quem faz a primeira leitura completa e como o time vai acompanhar os planos de ação.
- [ ] Definir quem decide sobre os planos sugeridos e quem mantém a ferramenta (veja `PEDIR-AJUSTES.md`).
- [ ] Revisar com Privacidade e Legal o acesso aos dados.
