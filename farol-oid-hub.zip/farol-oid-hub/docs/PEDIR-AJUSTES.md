# Como pedir ajustes no futuro

Copie o texto abaixo, preencha a última parte e cole numa conversa com o Claude. Ele leva o contexto completo, porque o Claude não lembra conversas anteriores.

```
Preciso de um ajuste na ferramenta "Farol OID", que você construiu como artifact publicado.

LINK DO ARTIFACT (edite este mesmo, não crie outro):
https://claude.ai/artifact/KTNyW3rftFRejgVRhzoHcR

COMO TRABALHAR
- Antes de mexer, leia o arquivo atual pelo link (Artifact, action "read") para partir da versão publicada.
- Faça a alteração com action "edit" ou republique com a mesma URL (parâmetro url), sem criar um segundo artifact.
- Mantenha as capabilities declaradas hoje: db, user, sample e mcp (Slack: slack_read_channel e slack_read_thread; Atlassian: getJiraIssue). Antes de usar o mcp, peça action "capabilities" e leia o contrato em /mnt/user-data/outputs/artifacts/_contract/.
- Teste a sintaxe do JavaScript e simule o carregamento antes de publicar. Diga o que você não conseguiu testar.

O QUE A FERRAMENTA FAZ
- Reúne os casos do canal privado #operational-intelligence-desk (ID C0A0EC24DJ6), com o link do ticket no Jira (nubank.atlassian.net), o resumo do ticket, o passo a passo da thread, a resposta enviada e um plano de ação.
- Abas: OOS, Simba, LW Suits, Resposta enviada e Plano de ação. Topo: botões Atualizar, Parar, Plano de ação e botão de tema (sol e lua). Filtro por mês de abertura e campo de busca (aceita datas como 19/11 e 2026-11-19).
- Assistente no canto inferior direito, o "Inspetor Roxinho" (mascote detetive roxo), com perguntas sugeridas em lista vertical.
- Visual na paleta do Nubank (roxo #820ad1), com tela clara e escura.
- O botão Atualizar lê o canal inteiro, registra todos os casos para todos e resume os pendentes, do mais novo para o mais antigo (até 40 por clique).
- Regras de classificação por time: OOS por padrão (@oos-oid); Simba quando o time de Simba (por exemplo Felipe Rocha) assume o caso na thread; LW Suits para pedidos de dossiê (@lawsuits-oid), fraude SISBAJUD e casos conduzidos por Lívia Zaroni ou Íris Almeida. "Alinhamentos" (@focais-agora-judorders) ficam de fora de propósito.

DADOS COMPARTILHADOS (db)
- Coleção "cases": um documento por ticket (JOI-xxx).
- Documentos: meta/index, meta/sync, meta/lock e meta/plan.
- Se eu pedir mudança no formato dos dados, avise antes e diga o que acontece com os documentos já gravados.

REGRAS
- Tudo em português do Brasil.
- Não gravar nem exibir CPF, CNPJ de pessoa física, número de conta ou dados bancários pessoais.
- Todo texto vindo do banco ou do Claude deve ser escapado antes de aparecer na tela.
- Manter acessibilidade (foco visível, contraste, respeitar movimento reduzido).
- Quem precisa atualizar precisa ter o nível de Colaborador (Contributor) no compartilhamento, estar no canal e ter Slack e Jira conectados.

MEU PEDIDO
- O que quero mudar: [descreva]
- Onde fica na tela: [aba, botão ou campo]
- Como deve ficar: [descreva, se possível com um exemplo]
- O que NÃO pode mudar: [por exemplo, dados já gravados, cores, nomes]
- Se algo for ambíguo, faça no máximo uma pergunta antes de começar.
```

Se o artifact for recriado em outro lugar, anexe também a pasta `docs/` e o arquivo `farol-oid.html` deste pacote à conversa e troque o link acima.

## Dicas

- **Pedido visual:** descreva o que vê e o que gostaria de ver, e diga se foi no computador ou no celular.
- **Erro:** copie a mensagem exata da faixa de aviso da página, logo abaixo do topo.
- **Dado errado em um caso:** informe o número do JOI e o que está errado. Em geral o ajuste é no dado gravado, não na página.
- **Mudar texto de prompt:** os textos estão em `PROMPTS.md`. Peça a mudança pelo nome do prompt (por exemplo, "prompt 2, plano de ação por caso").
