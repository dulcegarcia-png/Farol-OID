# Arquitetura

## 1. Visão geral

Página única, sem framework. O código-fonte fica em `src/index.html`, `src/styles.css` e `src/app.js`; `node build.js` os junta em `farol-oid.html`, o arquivo que se publica. O JavaScript tem cerca de 1.500 linhas, é puro, e o CSS usa variáveis para as cores. A página é desenhada para rodar **dentro do claude.ai**, onde recebe `window.claude`, uma ponte que dá acesso a quatro recursos (capabilities):

```
┌─────────────────────────── farol-oid.html (no navegador, dentro do claude.ai) ──────────────────────────┐
│  Interface (abas, busca, filtro, plano, assistente)                                                      │
│        │ lê/gera                                                                                         │
│        ▼                                                                                                 │
│  Estado em memória:  CASES = BASE_CASES + índice (stubs) + documentos de cases/                          │
│        ▲                                         ▲                         ▲                             │
│        │ onSnapshot                              │ callTool                │ sample()/sample.json()      │
└────────┼─────────────────────────────────────────┼─────────────────────────┼─────────────────────────────┘
         │                                         │                         │
   db (banco compartilhado)               mcp (conectores do usuário)   sample (Claude do usuário)
   cases/, meta/index, meta/sync,         Slack: slack_read_channel,    resumo do caso, plano por caso,
   meta/plan, meta/lock                   slack_read_thread             plano consolidado, assistente
                                          Atlassian: getJiraIssue
   user: user.can("data.write")
```

## 2. Capabilities declaradas

Arquivo `manifest/capabilities.json`:

| Capability | Uso no código |
|---|---|
| `db` | `db.collection("cases").onSnapshot`, `db.doc("meta/…").onSnapshot/set/acquire`, `db.doc("cases/JOI-nnn").set`. |
| `mcp` | `mcp.callTool("Slack", …)` e `mcp.callTool("Atlassian", …)` dentro de `call()`. |
| `sample` | `sample.json(prompt, { modelTier: "default" })` e `sample(input, { onText })`. |
| `user` | `user.can("data.write")` para desligar os botões de gravação para quem só lê. |

Todas são obtidas com `claude.use(nome)` e tratam o caso de virem `null`, quando o recurso não existe naquela visualização.

## 3. Chamadas a sistemas externos

### Slack (conector “Slack”)
| Ferramenta | Entrada usada | Onde |
|---|---|---|
| `slack_read_channel` | `{ channel_id: "C0A0EC24DJ6", limit: 100, response_format: "detailed", cursor? }` | `readWholeChannel()`, com paginação pelo cursor devolvido em `pagination_info`. |
| `slack_read_thread` | `{ channel_id, message_ts, limit: 200 }` | `refresh()`, uma vez por caso. |

O texto devolvido tem blocos separados por `=== Message from`, cada um com `Message TS:`, o link `browse/JOI-nnn|título`, `Prazo: aaaa-mm-dd` e `Thread: n replies`. `parseChannel()` depende desse formato.

### Jira (conector “Atlassian”)
| Ferramenta | Entrada usada | Onde |
|---|---|---|
| `getJiraIssue` | `{ cloudId: "nubank.atlassian.net", issueIdOrKey, fields: [summary, description, status, labels, assignee, reporter, created, comment], responseContentFormat: "markdown" }` | `refresh()`, uma vez por caso. |

### Claude (`sample`)
Quatro usos, todos no nível `default`: leitura de um caso, plano de um caso, plano consolidado e assistente. Os textos estão em `PROMPTS.md`.

## 4. Organização do código

Ordem aproximada dentro do `<script>`:

| Bloco | Conteúdo principal |
|---|---|
| Dados iniciais | `CASES` (10 casos embutidos), `BASE_CASES`, `BASE_PLANS`, `TEAMS`, `HINTS`. |
| Renderização | `esc`, `hl`, `blob`, filtros de mês (`openDate`, `monthKey`, `fillMonths`), `matches`, `renderTabs`, `caseHtml`, `respHtml`, `render`. |
| Tema | `currentTheme`, `paintTheme`, `setTheme`. |
| Atualizar | constantes (`CHANNEL`, `SLACK_SRV`, `JIRA_SRV`, `CLOUD`, `MAX_PER_CLICK`), `call`, `asText`, `asObject`, `jiraBrief`, `parseChannel`, `buildPrompt`, `cleanCase`, `cleanItem`, `stubCase`, `rebuild`, `subscribe`, `readWholeChannel`, `refresh`. |
| Plano de ação | `cleanPlan`, `cleanTheme`, `cleanPlanDoc`, `planView`, `planPrompt`, `runJob`, `genMissing`, `genConsolidated`. |
| Assistente | `chatDigest`, `chatContext`, `askChat`, `addSuggestions`, `goToCase`, `initAssistant`. |
| Inicialização | `initRefresh()` obtém as capabilities, assina o banco e liga os botões. |

### Variáveis globais importantes
- `CASES`: lista que a tela mostra. Reconstruída por `rebuild()` a cada mudança no banco.
- `BASE_CASES`: os 10 casos embutidos (base fixa).
- `REMOTE`: documentos de `cases/` já limpos.
- `INDEX`: itens de `meta/index`.
- `PLAN_DOC`: conteúdo de `meta/plan`.
- `busy`, `stopRequested`: estado de uma leitura em andamento.
- `mcp`, `sample`, `db`: capabilities resolvidas (ou `null`).
- `canWrite`: falso quando a pessoa só tem acesso de leitura.

### Como o estado é montado (`rebuild`)
1. cada item do índice vira um caso “Aguardando leitura” (`stubCase`);
2. os 10 casos embutidos substituem os de mesmo ID;
3. os documentos de `cases/` substituem os anteriores.

Assim, o que foi lido de verdade sempre prevalece sobre o que é só índice ou base.

## 5. Concorrência

- `meta/lock` usa `acquire` do banco (lease com validade). Cada clique de Atualizar, de “Gerar planos pendentes” ou de “Atualizar plano consolidado” tenta a trava primeiro (`runJob` e `refresh`).
- A trava é renovada a cada caso e encurtada ao final.
- Cada caso é gravado em um documento próprio, então gravações de casos diferentes não se sobrescrevem.
- `meta/sync` e `meta/index` são regravados inteiros (última escrita vence).

## 6. Tratamento de erros

`errMessage(e)` traduz o código de erro em uma frase com a ação possível: conector não conectado, conexão expirada, seleção de conexão, permissão negada, política da organização, limite de chamadas, serviço fora do ar, erro da ferramenta, acesso só de leitura, limite de armazenamento e acesso revogado. Leituras com erro marcado como repetível têm uma nova tentativa, depois de uma pausa curta.

## 7. Visual

- Variáveis CSS em `:root` (claro) e `:root[data-theme="dark"]` (escuro), mais `@media (prefers-color-scheme: dark)` para quem não escolheu.
- Paleta: roxo `#820ad1` (marca), `#5e0897`, lilás `#f0e3fb`, dourado só na lupa do mascote.
- Fontes: Public Sans (interface) e Newsreader (texto das respostas), carregadas do Google Fonts, com fontes de sistema como reserva.
- O farol e o mascote são SVG embutido (o mascote fica num `<symbol id="mascot">` reutilizado por `<use>`).
- Respeita `prefers-reduced-motion` e a área segura de telas com entalhe (`env(safe-area-inset-*)`).

## 8. Restrições do ambiente do claude.ai

A página publicada roda com uma política de conteúdo restrita:
- scripts externos só de `cdnjs.cloudflare.com`, `cdn.jsdelivr.net/npm/`, `cdn.tailwindcss.com` e `code.jquery.com`; folhas de estilo só do Google Fonts; sem chamadas de rede a outros sites;
- por isso o código não usa bibliotecas externas e **não chama nenhuma API diretamente**: tudo passa por `window.claude`;
- `localStorage` funciona, mas é privado de cada navegador. É usado só para a escolha de tema.
